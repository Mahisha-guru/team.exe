# STEAM.exe – The World's Most Inconvenient Machine

> **Hackathon Theme:** Steampunk + Intentionally Bad Game Design  
> **Mission:** Brew ONE solitary cup of tea for Professor Cogsworth.

---

## ☕ Overview

**STEAM.exe** is a fully playable, browser-based 2D steampunk comedy puzzle game built for the Hackathon. 

The year is 1889. Renowned Victorian inventor **Professor Cogsworth** has spent 27 years, 14 boiler explosions, and £4,000,000 of the Queen's treasury constructing a gargantuan 10-ton steam machine with one objective: **to produce ONE cup of tea**.

Accompanied by his sarcastic automaton **Sir Clankington Mk. II**, the player must navigate five stages of delightfully frustrating, intentionally terrible mechanical challenges where every law of good ergonomics has been cheerfully discarded.

---

## 🎮 The Five Calamitous Stages

### 1. Stage I: Wake the Machine
- **Objective:** Identify the correct starting lever among five deceptively labeled toggles.
- **The Catch:** Misleading Victorian labels (`Definitely Not Start`, `Emergency Tea Flush`, `Do Not Pull (Treason!)`, `Pull Me Maybe`, `Official Start Lever`).
- **Hint:** Victorian reverse psychology: the one forbidding you to pull is the only one wired to the firebox.

### 2. Stage II: Boiler Panic
- **Objective:** Keep steam pressure within the highlighted safe zone for 20 cumulative seconds.
- **The Catch:** The safe zone shifts periodically due to "thermodynamic inflation", accompanied by terrible machine advice ("More pressure means more success! Probably.").
- **Danger:** Exceeding 100 PSI causes a catastrophic boiler detonation!

### 3. Stage III: The Gear Disaster
- **Objective:** Synchronize all four rotating brass and bronze gears with their target housing notches.
- **The Catch:** In accordance with Inventor Law #44, rotational controls reverse every 10 seconds! A klaxon sounds and a countdown warns when left becomes right.

### 4. Stage IV: The Department of Unnecessary Permissions
- **Objective:** Submit **Form 42-B** to Her Majesty's Imperial Ministry of Thermal Agitation to legally authorize the boiling of water molecules.
- **The Catch:** Absurd bureaucratic inquiries ("What is the emotional state of your kettle?", "Have you obtained written consent from the water?").
- **Audit Margin Notes:** Toggle the inspector's cheat sheet to uncover the required constitutional answers and avoid the dreaded red **REJECTED** stamp.

### 5. Stage V: The Final Cup of Tea
- **Objective:** Execute the multi-stage brew sequence:
  1. Turn Master Ignition Key
  2. Stabilize Auxiliary Steam Pressure (60-80 PSI)
  3. Trip Safety Lockout Lever
  4. Deposit Camellia Sinensis tea leaves into the hopper
  5. Depress the Master Infusion Plunger
- **The Climax:** A dramatic 5-second countdown with shaking machinery, blazing pipes, sirens, and steam geysers... followed by the emergence of a 1cm teacup containing a single drop of lukewarm tea.
- **Final Score:** **1 / 10** ("Tea was slightly cold.")

---

## ⚙️ Intentionally Bad Game Design Features

1. **Misleading Button Labels:** Trusting an "Official" label results in soot and ridicule.
2. **Periodically Reversed Controls:** Every 10 seconds in the gear puzzle, Left becomes Right.
3. **Unnecessary Victorian Paperwork:** Even boiling water requires a notarized permit from the River Thames.
4. **Overdramatic Warning Klaxons:** Minor temperature fluctuations trigger full alarms.
5. **Ridiculously Unhelpful Machine Advice:** "Red zone indicates maximum British passion."
6. **The Erratic Productivity Meter:** A progress bar that fluctuates wildly and runs backwards while real milestone progress is tracked separately.
7. **Excessive Screen Shake & Steam FX:** Violent rumbling and mechanical shuddering upon lever pulls and detonations.
8. **Sir Clankington:** A sarcastic automaton who roasts your mistakes, animated with twitching monocle and chimney exhaust.

---

## 🛠️ Technology Stack

- **Framework:** React 19 + TypeScript + Vite
- **Visuals & Rendering:** HTML5 Canvas (procedural pressure gauge, animated gear train, floating steam particles, falling celebration confetti) + Tailwind CSS
- **Audio Engine:** 100% self-contained procedural audio synthesized via the **Web Audio API** (metallic clicks, gear ratchets, steam vents, alarms, desk stamps, robot synth talk, fanfare). No missing MP3 files!
- **State & Storage:** LocalStorage for imperial medals and audio settings, plus **Cloud Firestore** for the global live telegraph speedrun leaderboard.
- **Backend & Auth:** Firebase Firestore database + Google Authentication for player speedrun identity.

---

## 🚀 Running the Game Locally

```bash
# 1. Install dependencies
npm install

# 2. Launch development server
npm run dev
```

Open your browser at `http://localhost:3000`.

---

## 🏆 Imperial Medals (Achievements)

- **Certified Button Presser:** Interacted with deceptive levers without giving up.
- **Professional Steam Victim:** Exploded the boiler in pursuit of warm beverage.
- **Defier of Reverse Torque:** Aligned gears under inverted controls.
- **Government Approved Tea Maker:** Successfully had Form 42-B stamped.
- **Worst Inventor of 1889:** Completed the game and achieved the glorious 1/10 rating.
- **Steeled Against Sarcasm:** Endured 8 or more Victorian insults from Sir Clankington.

---

*Crafted with brass, coal, and intentional inconvenience.*
