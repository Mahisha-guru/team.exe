export type GameScreen = 
  | 'TITLE'
  | 'INSTRUCTIONS'
  | 'PLAYING'
  | 'TRANSITION'
  | 'PAUSED'
  | 'GAMEOVER'
  | 'VICTORY';

export type LevelId = 1 | 2 | 3 | 4 | 5;

export interface LevelConfig {
  id: LevelId;
  title: string;
  subtitle: string;
  objective: string;
  inventorNote: string;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlocked: boolean;
}

export interface GameStats {
  timeElapsed: number; // in seconds
  boilerBreaches: number;
  attemptsLost: number;
  steamVentedLiters: number;
  permitsSubmitted: number;
  insultsEndured: number;
}
