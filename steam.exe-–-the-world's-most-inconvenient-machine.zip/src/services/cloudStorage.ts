import { 
  collection, 
  addDoc, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  onSnapshot,
  doc,
  setDoc,
  getDoc
} from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from './firebase';
import { GameStats } from '../types/game';

export interface LeaderboardEntry {
  id?: string;
  userId: string;
  inventorName: string;
  timeElapsed: number;
  boilerBreaches: number;
  steamVentedLiters: number;
  permitsSubmitted: number;
  insultsEndured: number;
  completed: boolean;
  createdAt: string;
}

const LEADERBOARD_COLLECTION = 'leaderboard';
const USERS_COLLECTION = 'users';

export const CloudStorageService = {
  /**
   * Listen to top 20 speedrun records from Firestore
   */
  subscribeToLeaderboard(callback: (entries: LeaderboardEntry[]) => void): () => void {
    const q = query(
      collection(db, LEADERBOARD_COLLECTION),
      orderBy('timeElapsed', 'asc'),
      limit(20)
    );

    return onSnapshot(
      q,
      (snapshot) => {
        const entries: LeaderboardEntry[] = [];
        snapshot.forEach((docSnap) => {
          entries.push({
            id: docSnap.id,
            ...(docSnap.data() as Omit<LeaderboardEntry, 'id'>),
          });
        });
        callback(entries);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, LEADERBOARD_COLLECTION);
      }
    );
  },

  /**
   * Submit a run to the global imperial leaderboard
   */
  async submitScore(stats: GameStats, inventorName: string): Promise<string | null> {
    const user = auth.currentUser;
    if (!user) {
      console.warn("User not authenticated; unable to submit to Firebase leaderboard.");
      return null;
    }

    const payload: Omit<LeaderboardEntry, 'id'> = {
      userId: user.uid,
      inventorName: inventorName.trim() || 'Anonymous Inventor',
      timeElapsed: stats.timeElapsed,
      boilerBreaches: stats.boilerBreaches,
      steamVentedLiters: Math.round(stats.steamVentedLiters),
      permitsSubmitted: stats.permitsSubmitted,
      insultsEndured: stats.insultsEndured,
      completed: true,
      createdAt: new Date().toISOString(),
    };

    try {
      const docRef = await addDoc(collection(db, LEADERBOARD_COLLECTION), payload);
      return docRef.id;
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, LEADERBOARD_COLLECTION);
      return null;
    }
  },

  /**
   * Sync user profile medals and stats
   */
  async syncUserProfile(unlockedAchievements: string[], bestTime: number | null): Promise<void> {
    const user = auth.currentUser;
    if (!user) return;

    const path = `${USERS_COLLECTION}/${user.uid}`;
    try {
      await setDoc(doc(db, USERS_COLLECTION, user.uid), {
        userId: user.uid,
        displayName: user.displayName || 'Victorian Inventor',
        bestTime: bestTime,
        unlockedAchievements: unlockedAchievements.join(','),
        updatedAt: new Date().toISOString(),
      }, { merge: true });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  }
};
