import { Achievement, GameStats } from '../types/game';

export const INITIAL_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'button_presser',
    title: 'Certified Button Presser',
    description: 'Interacted with the deceptive levers without giving up in disgust.',
    icon: '🕹️',
    unlocked: false,
  },
  {
    id: 'steam_victim',
    title: 'Professional Steam Victim',
    description: 'Experienced a catastrophic boiler detonation in the pursuit of warm beverage.',
    icon: '💥',
    unlocked: false,
  },
  {
    id: 'gear_survivor',
    title: 'Defier of Reverse Torque',
    description: 'Successfully aligned gears while Her Majesty reversed your controls.',
    icon: '⚙️',
    unlocked: false,
  },
  {
    id: 'government_approved',
    title: 'Government Approved Tea Maker',
    description: 'Obtained official Form 42-B clearance to agitate hot water molecules.',
    icon: '📜',
    unlocked: false,
  },
  {
    id: 'worst_inventor',
    title: 'Worst Inventor of 1889',
    description: 'Operated the £4,000,000 machine to produce a lukewarm 1/10 cup of tea.',
    icon: '☕',
    unlocked: false,
  },
  {
    id: 'clankington_friend',
    title: 'Steeled Against Sarcasm',
    description: 'Endured 8 or more Victorian insults from Sir Clankington.',
    icon: '🤖',
    unlocked: false,
  },
];

export const StorageService = {
  getAchievements(): Achievement[] {
    try {
      const saved = localStorage.getItem('steam_achievements');
      if (saved) {
        const parsed = JSON.parse(saved);
        return INITIAL_ACHIEVEMENTS.map(ach => ({
          ...ach,
          unlocked: Boolean(parsed[ach.id]),
        }));
      }
    } catch {
      // fallback
    }
    return [...INITIAL_ACHIEVEMENTS];
  },

  unlockAchievement(id: string): Achievement | null {
    try {
      const saved = localStorage.getItem('steam_achievements');
      const unlockedMap: Record<string, boolean> = saved ? JSON.parse(saved) : {};
      if (!unlockedMap[id]) {
        unlockedMap[id] = true;
        localStorage.setItem('steam_achievements', JSON.stringify(unlockedMap));
        const item = INITIAL_ACHIEVEMENTS.find(a => a.id === id);
        return item ? { ...item, unlocked: true } : null;
      }
    } catch {
      // fallback
    }
    return null;
  },

  getBestTime(): number | null {
    try {
      const saved = localStorage.getItem('steam_best_time');
      return saved ? parseFloat(saved) : null;
    } catch {
      return null;
    }
  },

  saveBestTime(timeSeconds: number) {
    try {
      const current = this.getBestTime();
      if (current === null || timeSeconds < current) {
        localStorage.setItem('steam_best_time', timeSeconds.toString());
      }
    } catch {
      // fallback
    }
  },
};
