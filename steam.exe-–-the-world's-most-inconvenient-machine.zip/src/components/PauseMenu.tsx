import React from 'react';
import { sound } from '../services/sound';
import { Play, RotateCcw, Volume2, VolumeX, Home, BookOpen } from 'lucide-react';

interface PauseMenuProps {
  onResume: () => void;
  onRestartLevel: () => void;
  onShowManual: () => void;
  onQuitToTitle: () => void;
  isMuted: boolean;
  onToggleSound: () => void;
}

export const PauseMenu: React.FC<PauseMenuProps> = ({
  onResume,
  onRestartLevel,
  onShowManual,
  onQuitToTitle,
  isMuted,
  onToggleSound,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#241710] border-4 border-[#874b17] rounded-xl p-6 sm:p-8 max-w-md w-full shadow-2xl text-center space-y-6 relative">
        <div className="absolute top-2 left-2 rivet" />
        <div className="absolute top-2 right-2 rivet" />
        <div className="absolute bottom-2 left-2 rivet" />
        <div className="absolute bottom-2 right-2 rivet" />

        <div className="space-y-1">
          <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
            Emergency Flywheel Brake Engaged
          </span>
          <h2 className="font-victorian text-3xl font-black text-[#ffd700]">
            OPERATIONS PAUSED
          </h2>
          <p className="font-typewriter text-xs text-[#a8a9ad] italic">
            "Sir Clankington taps his brass foot impatiently."
          </p>
        </div>

        <div className="space-y-3">
          <button
            onClick={() => {
              sound.playClick();
              onResume();
            }}
            className="w-full py-3 px-4 rounded-lg bg-gradient-to-r from-[#d4af37] to-[#b87333] hover:brightness-110 text-black font-victorian font-black text-sm border-2 border-[#ffd700] shadow-md hover:scale-102 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play size={18} className="fill-black" />
            <span>RESUME OPERATIONS</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onRestartLevel();
            }}
            className="w-full py-2.5 px-4 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#f5e6c8] font-victorian font-bold text-xs border border-[#874b17] hover:border-[#ffd700] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw size={16} />
            <span>RESTART CURRENT STAGE</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onShowManual();
            }}
            className="w-full py-2.5 px-4 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#f5e6c8] font-victorian font-bold text-xs border border-[#874b17] hover:border-[#ffd700] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <BookOpen size={16} />
            <span>CONSULT PATENT MANUAL</span>
          </button>

          <button
            onClick={() => {
              onToggleSound();
            }}
            className="w-full py-2.5 px-4 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#ffd700] font-victorian font-bold text-xs border border-[#874b17] hover:border-[#ffd700] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            {isMuted ? <VolumeX size={16} /> : <Volume2 size={16} />}
            <span>AUDIO FX: {isMuted ? 'DISABLED' : 'ACTIVE'}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onQuitToTitle();
            }}
            className="w-full py-2.5 px-4 rounded-lg bg-[#2e150b] hover:bg-[#441f10] text-[#b22222] hover:text-[#d33a3a] font-victorian font-bold text-xs border border-[#874b17] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home size={16} />
            <span>ABORT RUN & RETURN TO TITLE</span>
          </button>
        </div>
      </div>
    </div>
  );
};
