import React from 'react';
import { sound } from '../services/sound';
import { X, Award, CheckCircle2, Lock } from 'lucide-react';
import { Achievement } from '../types/game';

interface AchievementsModalProps {
  isOpen: boolean;
  onClose: () => void;
  achievements: Achievement[];
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  isOpen,
  onClose,
  achievements,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#241710] border-4 border-[#874b17] rounded-xl p-6 max-w-lg w-full shadow-2xl relative max-h-[90vh] flex flex-col">
        <div className="absolute top-2 left-2 rivet" />
        <div className="absolute top-2 right-2 rivet" />
        <div className="absolute bottom-2 left-2 rivet" />
        <div className="absolute bottom-2 right-2 rivet" />

        {/* Header */}
        <div className="flex items-center justify-between border-b-2 border-[#874b17] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Award className="text-[#ffd700]" size={24} />
            <div>
              <h3 className="font-victorian text-lg font-bold text-[#ffd700]">
                IMPERIAL PATENTS & MEDALS
              </h3>
              <p className="text-[10px] font-mono-steampunk text-[#a8a9ad]">
                {achievements.filter(a => a.unlocked).length} of {achievements.length} Medals Conferred
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1 rounded text-[#a8a9ad] hover:text-white hover:bg-[#3d2516] transition-all cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* Medal List */}
        <div className="overflow-y-auto space-y-3 pr-1 flex-1">
          {achievements.map(ach => (
            <div
              key={ach.id}
              className={`p-3 rounded-lg border flex items-start gap-3 transition-all ${
                ach.unlocked
                  ? 'bg-[#2f1f15] border-[#d4af37] shadow-md'
                  : 'bg-[#180f0a] border-[#442510] opacity-50'
              }`}
            >
              <div className="text-2xl p-1.5 bg-[#120a06] border border-[#6d4018] rounded flex items-center justify-center">
                {ach.unlocked ? ach.icon : <Lock size={20} className="text-[#874b17]" />}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h4 className="font-victorian text-xs font-bold text-[#ffd700]">
                    {ach.title}
                  </h4>
                  {ach.unlocked && (
                    <span className="text-[10px] text-green-400 font-mono-steampunk flex items-center gap-0.5">
                      <CheckCircle2 size={12} /> Awarded
                    </span>
                  )}
                </div>

                <p className="font-typewriter text-xs text-[#d4af37]/80 mt-0.5 leading-tight">
                  {ach.description}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#874b17] mt-3 text-center">
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="py-2 px-6 rounded bg-brass-plate text-black font-victorian font-bold text-xs border border-[#ffd700] hover:brightness-110 cursor-pointer"
          >
            RETURN TO DUTY
          </button>
        </div>
      </div>
    </div>
  );
};
