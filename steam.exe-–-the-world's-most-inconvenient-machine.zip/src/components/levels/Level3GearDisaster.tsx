import React, { useState, useEffect, useRef } from 'react';
import { sound } from '../../services/sound';
import { SirClankington } from '../SirClankington';
import { RotateCcw, RotateCw, CheckCircle, AlertOctagon } from 'lucide-react';

interface Level3Props {
  onSuccess: () => void;
  attempts: number;
}

interface GearData {
  id: number;
  name: string;
  metal: string;
  currentAngle: number;
  targetAngle: number;
  radius: number;
  teeth: number;
  x: number;
  y: number;
  color: string;
  isAligned: boolean;
}

export const Level3GearDisaster: React.FC<Level3Props> = ({ onSuccess }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // 4 Gears layout
  const [gears, setGears] = useState<GearData[]>([
    {
      id: 1,
      name: "Driver Sun Gear",
      metal: "Burnished Brass",
      currentAngle: 140,
      targetAngle: 0, // Top
      radius: 54,
      teeth: 16,
      x: 100,
      y: 110,
      color: "#d4af37",
      isAligned: false,
    },
    {
      id: 2,
      name: "Secondary Idler",
      metal: "Oxidized Copper",
      currentAngle: 220,
      targetAngle: 90, // Right
      radius: 46,
      teeth: 12,
      x: 230,
      y: 100,
      color: "#b87333",
      isAligned: false,
    },
    {
      id: 3,
      name: "Torsional Pinion",
      metal: "Forged Bronze",
      currentAngle: 60,
      targetAngle: 180, // Bottom
      radius: 40,
      teeth: 10,
      x: 350,
      y: 130,
      color: "#cd7f32",
      isAligned: false,
    },
    {
      id: 4,
      name: "Crown Escapement",
      metal: "Imperial Gold",
      currentAngle: 310,
      targetAngle: 270, // Left
      radius: 58,
      teeth: 18,
      x: 240,
      y: 220,
      color: "#ffd700",
      isAligned: false,
    },
  ]);

  const [selectedGearId, setSelectedGearId] = useState<number>(1);
  const [isInverted, setIsInverted] = useState<boolean>(false);
  const [invertCountdown, setInvertCountdown] = useState<number>(10);
  const [allAligned, setAllAligned] = useState<boolean>(false);
  const [clankMessage, setClankMessage] = useState<string>('');

  // 10-Second Reverse Controls Timer
  useEffect(() => {
    const timer = setInterval(() => {
      setInvertCountdown(prev => {
        if (prev <= 1) {
          setIsInverted(curr => {
            const nextInverted = !curr;
            sound.playAlarm();
            if (nextInverted) {
              setClankMessage("Surprise! Left is now right, and right is left. Enjoy Victorian ergonomics.");
            } else {
              setClankMessage("Controls returned to normal. Do not get used to it.");
            }
            return nextInverted;
          });
          return 10;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  // Check alignment
  const checkAlignment = (angle: number, target: number) => {
    const normalized = (angle % 360 + 360) % 360;
    const diff = Math.abs(normalized - target);
    const circularDiff = Math.min(diff, 360 - diff);
    return circularDiff <= 9; // 9 degree tolerance
  };

  const handleRotate = (rawDirection: 'left' | 'right') => {
    if (allAligned) return;

    // Apply intentional inversion if active
    const actualDirection = isInverted
      ? rawDirection === 'left' ? 'right' : 'left'
      : rawDirection;

    const delta = actualDirection === 'right' ? 15 : -15;
    sound.playGear(actualDirection);

    setGears(prevGears => {
      const updated = prevGears.map(gear => {
        if (gear.id === selectedGearId) {
          const nextAngle = (gear.currentAngle + delta + 360) % 360;
          const aligned = checkAlignment(nextAngle, gear.targetAngle);
          if (aligned && !gear.isAligned) {
            sound.playClick(1.4);
          }
          return {
            ...gear,
            currentAngle: nextAngle,
            isAligned: aligned,
          };
        }
        return gear;
      });

      // Check if all are aligned
      const isEveryAligned = updated.every(g => g.isAligned);
      if (isEveryAligned && !allAligned) {
        setAllAligned(true);
        sound.playVictory();
        setClankMessage("Remarkable! All four gears are synchronized. The machine lives!");
        setTimeout(() => {
          onSuccess();
        }, 1800);
      }

      return updated;
    });
  };

  // Render Gears on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw background grid / engineering parchment blueprint
    ctx.strokeStyle = 'rgba(212, 175, 55, 0.08)';
    ctx.lineWidth = 1;
    for (let x = 0; x < canvas.width; x += 30) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }
    for (let y = 0; y < canvas.height; y += 30) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }

    // Draw Gears
    gears.forEach(gear => {
      const isSelected = gear.id === selectedGearId;

      ctx.save();
      ctx.translate(gear.x, gear.y);

      // Selection indicator aura
      if (isSelected) {
        ctx.beginPath();
        ctx.arc(0, 0, gear.radius + 14, 0, Math.PI * 2);
        ctx.strokeStyle = '#ffd700';
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 4]);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Target Alignment Notch on housing (Fixed)
      const targetRad = (gear.targetAngle * Math.PI) / 180;
      const markerDistance = gear.radius + 10;
      const mx = Math.cos(targetRad) * markerDistance;
      const my = Math.sin(targetRad) * markerDistance;

      ctx.beginPath();
      ctx.arc(mx, my, 5, 0, Math.PI * 2);
      ctx.fillStyle = gear.isAligned ? '#22c55e' : '#b22222';
      ctx.fill();
      ctx.strokeStyle = '#ffd700';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Rotate canvas for gear body
      const rad = (gear.currentAngle * Math.PI) / 180;
      ctx.rotate(rad);

      // Gear teeth
      const toothDepth = 7;
      const toothAngleStep = (Math.PI * 2) / gear.teeth;

      ctx.beginPath();
      for (let i = 0; i < gear.teeth; i++) {
        const a1 = i * toothAngleStep;
        const a2 = a1 + toothAngleStep * 0.4;
        const a3 = a1 + toothAngleStep * 0.6;
        const a4 = (i + 1) * toothAngleStep;

        const rOuter = gear.radius + toothDepth;
        const rInner = gear.radius;

        if (i === 0) {
          ctx.moveTo(Math.cos(a1) * rInner, Math.sin(a1) * rInner);
        }
        ctx.lineTo(Math.cos(a2) * rOuter, Math.sin(a2) * rOuter);
        ctx.lineTo(Math.cos(a3) * rOuter, Math.sin(a3) * rOuter);
        ctx.lineTo(Math.cos(a4) * rInner, Math.sin(a4) * rInner);
      }
      ctx.closePath();

      // Gear fill color (glows if aligned)
      ctx.fillStyle = gear.isAligned ? '#e6b800' : gear.color;
      ctx.fill();
      ctx.lineWidth = 2;
      ctx.strokeStyle = gear.isAligned ? '#ffffff' : '#3d2511';
      ctx.stroke();

      // Cutout circles (steam aesthetic spokes)
      ctx.beginPath();
      ctx.arc(0, 0, gear.radius * 0.65, 0, Math.PI * 2);
      ctx.fillStyle = '#1c120c';
      ctx.fill();
      ctx.stroke();

      // Center brass hub
      ctx.beginPath();
      ctx.arc(0, 0, 10, 0, Math.PI * 2);
      ctx.fillStyle = '#ffd700';
      ctx.fill();
      ctx.strokeStyle = '#4f270a';
      ctx.stroke();

      // Alignment pointer notch on gear rim
      ctx.beginPath();
      ctx.moveTo(gear.radius - 2, 0);
      ctx.lineTo(gear.radius + toothDepth + 3, 0);
      ctx.strokeStyle = gear.isAligned ? '#ffffff' : '#ffd700';
      ctx.lineWidth = 4;
      ctx.stroke();

      ctx.restore();

      // Gear Label
      ctx.fillStyle = isSelected ? '#ffd700' : '#a8a9ad';
      ctx.font = 'bold 10px Courier, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`GEAR ${gear.id}`, gear.x, gear.y + gear.radius + 24);
    });
  }, [gears, selectedGearId, allAligned]);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-5">
      {/* Top Banner */}
      <div className="bg-[#2a1a11] border-2 border-[#b87333] rounded-lg p-3.5 shadow-xl relative text-center">
        <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
          Stage III: Transmission Synchronization
        </span>
        <h2 className="font-victorian text-2xl font-bold text-[#ffd700]">
          THE GEAR DISASTER
        </h2>
        <p className="font-typewriter text-xs text-[#f5e6c8] max-w-xl mx-auto italic mt-1">
          Rotate all four Victorian gears so each alignment notch locks into its target socket.
          Beware: In accordance with Inventor Law #44, controls reverse every 10 seconds.
        </p>
      </div>

      {/* Sir Clankington */}
      <SirClankington level={3} customMessage={clankMessage} />

      {/* Main Interactive Machine Cabinet */}
      <div className="bg-iron-dark border-4 border-[#874b17] rounded-xl p-6 shadow-2xl relative">
        {/* Dynamic Warning Banner for Control Reversal */}
        <div
          className={`mb-4 p-2.5 rounded-lg border flex items-center justify-between px-4 transition-all ${
            isInverted
              ? 'bg-[#b22222]/90 border-[#ffd700] text-white animate-pulse'
              : 'bg-[#271911] border-[#874b17] text-[#d4af37]'
          }`}
        >
          <div className="flex items-center gap-2">
            <AlertOctagon size={18} className={isInverted ? 'text-yellow-300' : 'text-[#d4af37]'} />
            <span className="font-victorian text-xs font-bold tracking-wide">
              {isInverted
                ? '⚠️ CAUTION: REVERSE TORQUE ENGAGED – CONTROLS ARE INVERTED! (LEFT IS RIGHT)'
                : 'STATUS: STANDARD ROTATION PROTOCOL'}
            </span>
          </div>

          <div className="font-mono-steampunk text-xs font-bold">
            NEXT REVERSAL: <span className="text-[#ffd700]">{invertCountdown}s</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          {/* Canvas Section */}
          <div className="md:col-span-8 flex flex-col items-center">
            <div className="relative bg-[#160d08] rounded-xl border-2 border-[#6d4018] p-2 shadow-inner">
              <canvas
                ref={canvasRef}
                width={450}
                height={300}
                className="w-full max-w-[450px] cursor-pointer"
                onClick={e => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const clickX = ((e.clientX - rect.left) / rect.width) * 450;
                  const clickY = ((e.clientY - rect.top) / rect.height) * 300;

                  // Find clicked gear
                  const clicked = gears.find(g => {
                    const dist = Math.hypot(g.x - clickX, g.y - clickY);
                    return dist <= g.radius + 15;
                  });
                  if (clicked) {
                    setSelectedGearId(clicked.id);
                    sound.playClick(1.2);
                  }
                }}
              />
              <span className="absolute bottom-2 right-3 text-[9px] font-mono-steampunk text-[#a8a9ad]/70">
                (Click gear or use selector below)
              </span>
            </div>

            {/* Gear Selector Buttons */}
            <div className="flex gap-2 mt-3">
              {gears.map(gear => (
                <button
                  key={gear.id}
                  onClick={() => {
                    setSelectedGearId(gear.id);
                    sound.playClick(1.1);
                  }}
                  className={`px-3 py-1.5 rounded text-xs font-victorian font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                    selectedGearId === gear.id
                      ? 'bg-brass-plate text-black border-[#ffd700] shadow'
                      : 'bg-[#2b1a10] text-[#f5e6c8] border-[#874b17] hover:border-[#ffd700]'
                  }`}
                >
                  <span>Gear {gear.id}</span>
                  {gear.isAligned && <CheckCircle size={12} className="text-green-500" />}
                </button>
              ))}
            </div>
          </div>

          {/* Controls Section */}
          <div className="md:col-span-4 space-y-4">
            <div className="p-3 bg-[#1e130c] border border-[#874b17] rounded-lg text-center">
              <span className="text-xs font-victorian font-bold text-[#ffd700] block mb-1">
                SELECTED MECHANISM
              </span>
              <p className="font-mono-steampunk text-sm font-bold text-white">
                {gears.find(g => g.id === selectedGearId)?.name}
              </p>
              <span className="text-[10px] font-mono-steampunk text-[#d4af37] block mt-1">
                Alloy: {gears.find(g => g.id === selectedGearId)?.metal}
              </span>
              <div className="mt-2 text-xs font-mono-steampunk">
                {gears.find(g => g.id === selectedGearId)?.isAligned ? (
                  <span className="text-green-400 font-bold">✓ TEETH LOCKED & ENGAGED</span>
                ) : (
                  <span className="text-amber-400">ALIGN WITH TARGET NOTCH</span>
                )}
              </div>
            </div>

            {/* Rotation Buttons */}
            <div className="grid grid-cols-2 gap-3">
              <button
                disabled={allAligned}
                onClick={() => handleRotate('left')}
                className="py-4 px-2 rounded-lg bg-gradient-to-b from-[#874b17] to-[#4f270a] hover:from-[#a05a1e] hover:to-[#63330f] border-2 border-[#d4af37] text-[#ffd700] font-victorian font-bold text-xs shadow-lg active:scale-95 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer select-none"
              >
                <RotateCcw size={20} />
                <span>ROTATE LEFT</span>
                <span className="text-[9px] font-mono-steampunk text-[#e69138]">
                  {isInverted ? '(Actually Right)' : '(Counter-Clockwise)'}
                </span>
              </button>

              <button
                disabled={allAligned}
                onClick={() => handleRotate('right')}
                className="py-4 px-2 rounded-lg bg-gradient-to-b from-[#874b17] to-[#4f270a] hover:from-[#a05a1e] hover:to-[#63330f] border-2 border-[#d4af37] text-[#ffd700] font-victorian font-bold text-xs shadow-lg active:scale-95 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer select-none"
              >
                <RotateCw size={20} />
                <span>ROTATE RIGHT</span>
                <span className="text-[9px] font-mono-steampunk text-[#e69138]">
                  {isInverted ? '(Actually Left)' : '(Clockwise)'}
                </span>
              </button>
            </div>

            {/* Total progress */}
            <div className="p-2.5 bg-[#170e09] border border-[#6d4018] rounded text-center">
              <span className="text-[11px] font-mono-steampunk text-[#a8a9ad]">
                GEARS SYNCHRONIZED: {gears.filter(g => g.isAligned).length} / 4
              </span>
              <div className="w-full h-2 bg-[#0d0704] rounded-full mt-1.5 overflow-hidden">
                <div
                  className="h-full bg-[#22c55e] transition-all duration-300"
                  style={{ width: `${(gears.filter(g => g.isAligned).length / 4) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
