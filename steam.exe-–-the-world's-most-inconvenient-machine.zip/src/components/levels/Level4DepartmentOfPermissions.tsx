import React, { useState } from 'react';
import { sound } from '../../services/sound';
import { SirClankington } from '../SirClankington';
import { Stamp, CheckCircle2, XCircle, FileText, HelpCircle } from 'lucide-react';

interface Level4Props {
  onSuccess: () => void;
  attempts: number;
}

interface Question {
  id: string;
  question: string;
  options: { label: string; value: string; isCorrect: boolean }[];
  hint: string;
}

const QUESTIONS: Question[] = [
  {
    id: 'kettle_mood',
    question: "1. What is the certified emotional state of your kettle?",
    options: [
      { label: "Deep existential sorrow and mild weeping", value: "sorrow", isCorrect: false },
      { label: "Filled with unflinching patriotic zeal", value: "patriotic", isCorrect: true },
      { label: "Suspiciously indifferent to heat", value: "indifferent", isCorrect: false },
      { label: "Severe anxiety regarding impending steam expansion", value: "anxious", isCorrect: false },
    ],
    hint: "Regulation 4: Kettles lacking patriotic vigor are liable to imperial confiscation.",
  },
  {
    id: 'water_consent',
    question: "2. Have you obtained formal written consent from the water molecules?",
    options: [
      { label: "No, water is fundamentally anarchist in nature", value: "anarchist", isCorrect: false },
      { label: "Water agreed reluctantly under threat of freezing", value: "duress", isCorrect: false },
      { label: "Yes, duly notarized by Lord Thames himself", value: "notarized", isCorrect: true },
      { label: "The water pleaded the Fifth Amendment (Foreign nonsense)", value: "fifth", isCorrect: false },
    ],
    hint: "Statute 12: Only Thames-notarized fluids may legally undergo thermal excitement.",
  },
  {
    id: 'enthusiast_rank',
    question: "3. Are you legally recognized as a certified tea enthusiast?",
    options: [
      { label: "Grand Duke of Earl Grey (Order of the Silver Spoon)", value: "grand_duke", isCorrect: true },
      { label: "Casual sipper (Punishable by 40 lashes)", value: "casual", isCorrect: false },
      { label: "I privately prefer roasted coffee beans (HERESY)", value: "coffee", isCorrect: false },
      { label: "Only consume tea when accompanied by rich tea biscuits", value: "biscuit", isCorrect: false },
    ],
    hint: "Royal Decree: The permit cannot be granted to commoners below the rank of Grand Duke.",
  },
  {
    id: 'boil_reason',
    question: "4. State the constitutional justification for this expenditure of thermal energy:",
    options: [
      { label: "Personal mid-afternoon refreshment", value: "refreshment", isCorrect: false },
      { label: "To impress the neighborhood stray cats", value: "cats", isCorrect: false },
      { label: "To prevent the imminent collapse of British civilization", value: "collapse", isCorrect: true },
      { label: "Because the machine cost £4,000,000 and must do something", value: "cost", isCorrect: false },
    ],
    hint: "Emergency Clause 99: Boiling water for trivial thirst is forbidden; only national salvation qualifies.",
  },
];

export const Level4DepartmentOfPermissions: React.FC<Level4Props> = ({ onSuccess }) => {
  const [answers, setAnswers] = useState<Record<string, string>>({
    kettle_mood: '',
    water_consent: '',
    enthusiast_rank: '',
    boil_reason: '',
  });

  const [stampStatus, setStampStatus] = useState<'IDLE' | 'REJECTED' | 'APPROVED'>('IDLE');
  const [rejectionReasons, setRejectionReasons] = useState<string[]>([]);
  const [showCheatSheet, setShowCheatSheet] = useState<boolean>(false);
  const [clankMessage, setClankMessage] = useState<string>(
    "Ah, Form 42-B. The crown jewel of British civil service: preventing hydration through bureaucracy."
  );

  const handleSelectOption = (qId: string, val: string) => {
    sound.playClick(1.2);
    setAnswers(prev => ({ ...prev, [qId]: val }));
    if (stampStatus === 'REJECTED') {
      setStampStatus('IDLE');
    }
  };

  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();

    // Check completeness
    const unanswered = QUESTIONS.filter(q => !answers[q.id]);
    if (unanswered.length > 0) {
      sound.playAlarm();
      setClankMessage("You left questions blank! The clerk has already filed a complaint against your lineage.");
      setStampStatus('REJECTED');
      setRejectionReasons(["Incomplete documentation: All four absurd declarations must be checked."]);
      return;
    }

    // Evaluate answers
    const failures: string[] = [];
    QUESTIONS.forEach(q => {
      const selected = q.options.find(o => o.value === answers[q.id]);
      if (!selected || !selected.isCorrect) {
        failures.push(`Rejection on Question ${q.id}: ${q.hint}`);
      }
    });

    if (failures.length === 0) {
      // APPROVED!
      sound.playStamp(true);
      setStampStatus('APPROVED');
      setClankMessage("Inconceivable! You actually outwitted the Ministry of Permits! Prepare the tea leaves!");
      setTimeout(() => {
        onSuccess();
      }, 2000);
    } else {
      // REJECTED
      sound.playStamp(false);
      setStampStatus('REJECTED');
      setRejectionReasons(failures);
      setClankMessage(`Application denied! ${failures.length} infraction(s) detected. Read the inspector notes on the margin!`);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-5">
      {/* Top Banner */}
      <div className="bg-[#2a1a11] border-2 border-[#b87333] rounded-lg p-3.5 shadow-xl relative text-center">
        <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
          Stage IV: Regulatory Compliance
        </span>
        <h2 className="font-victorian text-2xl font-bold text-[#ffd700]">
          THE DEPARTMENT OF UNNECESSARY PERMISSIONS
        </h2>
        <p className="font-typewriter text-xs text-[#f5e6c8] max-w-xl mx-auto italic mt-1">
          Before steam may legally contact water, Her Majesty's Ministry demands completed Form 42-B.
          Review the auditor's annotations carefully to ensure immediate royal approval.
        </p>
      </div>

      {/* Sir Clankington */}
      <SirClankington level={4} customMessage={clankMessage} />

      {/* The Victorian Parchment Form 42-B */}
      <div className="bg-[#fbf4e2] text-[#2c1a0e] rounded-xl border-4 border-[#874b17] shadow-2xl p-6 sm:p-8 relative overflow-hidden font-typewriter">
        {/* Background watermark / faint stamp */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-5 pointer-events-none text-9xl font-victorian select-none">
          ROYAL PERMIT
        </div>

        {/* Parchment Header */}
        <div className="border-b-2 border-[#874b17] pb-4 mb-6 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full border-2 border-[#874b17] flex items-center justify-center font-victorian text-xl font-bold bg-[#ecdab3]">
              👑
            </div>
            <div>
              <h3 className="font-victorian text-base sm:text-lg font-bold text-[#4a2810] tracking-wider uppercase">
                Imperial Ministry of Thermal Agitation
              </h3>
              <p className="text-xs text-[#6e4624] italic">
                Form 42-B (Rev. 1889): Affidavit of Intent to Boil Aqueous Matter
              </p>
            </div>
          </div>

          {/* Toggle Cheat Sheet / Auditor Notes */}
          <button
            type="button"
            onClick={() => {
              sound.playClick(1.3);
              setShowCheatSheet(!showCheatSheet);
            }}
            className="px-3 py-1.5 rounded bg-[#edd7ae] border border-[#874b17] text-xs font-victorian font-bold text-[#4a2810] hover:bg-[#dec495] transition-all flex items-center gap-1 cursor-pointer"
          >
            <HelpCircle size={14} />
            <span>{showCheatSheet ? 'Hide Auditor Notes' : 'Read Auditor Notes'}</span>
          </button>
        </div>

        {/* Auditor Notes (Margin Clues) */}
        {showCheatSheet && (
          <div className="mb-6 p-4 bg-[#ecdab3] border-l-4 border-[#b87333] rounded text-xs space-y-1.5 text-[#3e220c]">
            <span className="font-bold font-victorian uppercase text-[#874b17] block mb-1">
              📌 Confidential Inspector's Scribbles:
            </span>
            <p>• The Queen only drinks from kettles inspired by patriotic fervor.</p>
            <p>• Un-notarized Thames water will be impounded by the River Police.</p>
            <p>• Anyone ranking below Grand Duke will be sentenced to lukewarm tap water.</p>
            <p>• Thermal energy is only sanctioned if the empire faces total destruction without tea.</p>
          </div>
        )}

        {/* Questions Form */}
        <form onSubmit={handleSubmitForm} className="space-y-6">
          {QUESTIONS.map(q => (
            <div key={q.id} className="p-3.5 rounded bg-[#f5ead1] border border-[#d6c19a]">
              <h4 className="font-bold text-sm text-[#381e09] mb-2.5">
                {q.question}
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {q.options.map(opt => {
                  const isChecked = answers[q.id] === opt.value;
                  return (
                    <label
                      key={opt.value}
                      className={`flex items-start gap-2.5 p-2 rounded border cursor-pointer transition-all text-xs ${
                        isChecked
                          ? 'bg-[#e2c792] border-[#874b17] font-bold shadow-sm'
                          : 'bg-[#faf3e3] border-[#e0cbab] hover:bg-[#f0dfbd]'
                      }`}
                    >
                      <input
                        type="radio"
                        name={q.id}
                        value={opt.value}
                        checked={isChecked}
                        onChange={() => handleSelectOption(q.id, opt.value)}
                        className="mt-0.5 accent-[#874b17]"
                      />
                      <span>{opt.label}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Rejection / Feedback Section */}
          {stampStatus === 'REJECTED' && (
            <div className="p-4 rounded bg-[#fbe2e2] border-2 border-[#b22222] text-[#7a1818] space-y-1">
              <div className="flex items-center gap-2 font-victorian font-bold text-sm">
                <XCircle size={18} className="text-[#b22222]" />
                <span>APPLICATION SUMMARY: REJECTED BY HER MAJESTY'S UNDERSECRETARY</span>
              </div>
              <ul className="list-disc list-inside text-xs space-y-1 mt-2">
                {rejectionReasons.map((reason, idx) => (
                  <li key={idx}>{reason}</li>
                ))}
              </ul>
              <span className="text-[11px] italic block mt-1">
                Tip: Click 'Read Auditor Notes' above to consult the official statutes!
              </span>
            </div>
          )}

          {/* Submit Button */}
          <div className="pt-4 flex flex-wrap items-center justify-between gap-4">
            <span className="text-xs text-[#874b17] italic">
              * Submission requires 0.3 pence processing fee (waived for geniuses).
            </span>

            <button
              type="submit"
              disabled={stampStatus === 'APPROVED'}
              className="py-3 px-6 rounded-lg bg-gradient-to-r from-[#874b17] to-[#4f270a] hover:from-[#a05a1e] hover:to-[#63330f] text-[#f7ecd5] font-victorian font-bold text-sm border-2 border-[#d4af37] shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Stamp size={18} />
              <span>SUBMIT APPLICATION FOR SCRUTINY</span>
            </button>
          </div>
        </form>

        {/* Large Slamming Stamp Graphics */}
        {stampStatus === 'APPROVED' && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 border-8 border-green-700 text-green-700 px-8 py-4 rounded-xl rotate-[-12deg] font-victorian font-black text-2xl sm:text-4xl tracking-widest uppercase bg-white/90 shadow-2xl pointer-events-none animate-bounce">
            ✓ APPROVED & NOTARIZED
          </div>
        )}

        {stampStatus === 'REJECTED' && (
          <div className="absolute top-1/3 right-8 border-8 border-red-700 text-red-700 px-6 py-3 rounded-xl rotate-[14deg] font-victorian font-black text-xl sm:text-3xl tracking-widest uppercase bg-white/90 shadow-2xl pointer-events-none animate-pulse">
            ✗ REJECTED
          </div>
        )}
      </div>
    </div>
  );
};
