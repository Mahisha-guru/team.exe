import React, { useState } from 'react';
import { sound } from '../../services/sound';
import { SirClankington } from '../SirClankington';

interface Level1Props {
  onSuccess: () => void;
  onFailAttempt: () => void;
  attempts: number;
}

interface Lever {
  id: number;
  label: string;
  sublabel: string;
  isCorrect: boolean;
  penaltyMessage: string;
  color: string;
}

const LEVERS: Lever[] = [
  {
    id: 1,
    label: "DEFINITELY NOT START",
    sublabel: "Seriously, why would it be?",
    isCorrect: false,
    penaltyMessage: "The machine whistles a mocking tune. A cold gust of air blows out.",
    color: "#874b17",
  },
  {
    id: 2,
    label: "EMERGENCY TEA FLUSH",
    sublabel: "For catastrophic tea excess",
    isCorrect: false,
    penaltyMessage: "A pipe spits lukewarm puddle water on your boots. Sir Clankington laughs.",
    color: "#b22222",
  },
  {
    id: 3,
    label: "DO NOT PULL (TREASON!)",
    sublabel: "Punishable by 100 years of decaf",
    isCorrect: true, // The true reverse-psychology lever!
    penaltyMessage: "",
    color: "#d4af37",
  },
  {
    id: 4,
    label: "PULL ME MAYBE",
    sublabel: "Recommended by no living engineer",
    isCorrect: false,
    penaltyMessage: "A tiny music box plays an out-of-tune waltz. Nothing else occurs.",
    color: "#997a15",
  },
  {
    id: 5,
    label: "OFFICIAL START LEVER (HONEST!)",
    sublabel: "Sealed with wax & gullibility",
    isCorrect: false,
    penaltyMessage: "Soot bursts from the exhaust! Classic rookie mistake: trusting an official label.",
    color: "#4f270a",
  },
];

export const Level1WakeMachine: React.FC<Level1Props> = ({
  onSuccess,
  onFailAttempt,
  attempts,
}) => {
  const [pulledLever, setPulledLever] = useState<number | null>(null);
  const [feedback, setFeedback] = useState<string>('');
  const [clankMessage, setClankMessage] = useState<string>('');
  const [isWakingUp, setIsWakingUp] = useState<boolean>(false);

  const handlePullLever = (lever: Lever) => {
    if (isWakingUp) return;
    sound.playClick(0.8 + lever.id * 0.1);
    setPulledLever(lever.id);

    if (lever.isCorrect) {
      // SUCCESS!
      setIsWakingUp(true);
      setFeedback("REVERSE PSYCHOLOGY VERIFIED! The boiler ignites with thunderous enthusiasm!");
      setClankMessage("Astonishing. You ignored the law and solved the puzzle. I am filing a complaint.");
      sound.playSteam(1.2, 0.8);

      setTimeout(() => {
        sound.playStamp(true);
        onSuccess();
      }, 1600);
    } else {
      // INCORRECT LEVER
      sound.playAlarm();
      setFeedback(lever.penaltyMessage);
      setClankMessage(`You pulled '${lever.label}'? Did you acquire your engineering degree from a cereal box?`);
      onFailAttempt();

      setTimeout(() => {
        setPulledLever(null);
      }, 800);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Top Patent Plaque */}
      <div className="bg-[#2a1a11] border-2 border-[#b87333] rounded-lg p-4 shadow-xl relative">
        <div className="absolute top-2 left-2 rivet" />
        <div className="absolute top-2 right-2 rivet" />
        <div className="absolute bottom-2 left-2 rivet" />
        <div className="absolute bottom-2 right-2 rivet" />

        <div className="text-center space-y-1">
          <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
            Imperial Patent #882-B – Operating Instructions
          </span>
          <h2 className="font-victorian text-2xl font-bold text-[#ffd700]">
            STAGE I: WAKE THE MACHINE
          </h2>
          <p className="font-typewriter text-xs text-[#f5e6c8] max-w-2xl mx-auto italic">
            "Notice to all Certified Engineers: Professor Cogsworth was notoriously paranoid.
            He specifically designed the startup console so that any lever claiming to be the start
            is an elaborate practical joke. Obey reverse psychology or suffer mild embarrassment."
          </p>
        </div>
      </div>

      {/* Sir Clankington Assistant */}
      <SirClankington level={1} customMessage={clankMessage} />

      {/* Main Lever Console */}
      <div className="bg-iron-dark border-4 border-[#874b17] rounded-xl p-6 shadow-2xl relative overflow-hidden">
        {/* Steam pipes background graphic */}
        <div className="absolute top-0 left-0 right-0 h-4 bg-gradient-to-r from-[#874b17] via-[#d4af37] to-[#874b17] opacity-60" />

        <div className="text-center mb-6">
          <h3 className="font-victorian text-lg text-[#ffd700] uppercase tracking-wider">
            Primary Transmission Levers
          </h3>
          <p className="text-xs font-mono-steampunk text-[#a8a9ad]">
            Identify and pull the solitary lever capable of firing the firebox.
          </p>
        </div>

        {/* The 5 Levers Row */}
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
          {LEVERS.map(lever => {
            const isPulled = pulledLever === lever.id;
            return (
              <div
                key={lever.id}
                className="flex flex-col items-center p-3 rounded-lg bg-[#22150d] border border-[#6d4018] shadow-md hover:border-[#ffd700] transition-all"
              >
                {/* Lever housing slot */}
                <div className="w-12 h-28 bg-[#120a06] border-2 border-[#4f270a] rounded-sm relative flex flex-col items-center justify-between py-2 shadow-inner">
                  {/* Vertical track line */}
                  <div className="w-1.5 h-full bg-[#351d0d] rounded-full absolute" />

                  {/* Lever shaft and ball handle */}
                  <div
                    className={`w-6 h-6 rounded-full border-2 transition-all duration-300 relative z-10 cursor-pointer shadow-lg flex items-center justify-center ${
                      isPulled
                        ? 'translate-y-16 bg-[#b22222] border-[#ffd700]'
                        : 'translate-y-0 bg-brass-plate border-[#ffd700] hover:scale-110'
                    }`}
                    onClick={() => handlePullLever(lever)}
                  >
                    <div className="w-2 h-2 rounded-full bg-white opacity-40" />
                  </div>
                </div>

                {/* Lever Action Button */}
                <button
                  disabled={isWakingUp}
                  onClick={() => handlePullLever(lever)}
                  className={`mt-4 w-full py-2 px-1 text-center rounded border transition-all cursor-pointer font-victorian text-xs font-bold leading-tight ${
                    isPulled
                      ? 'bg-[#d4af37] text-black border-[#ffd700]'
                      : 'bg-[#3b2315] hover:bg-[#52331d] text-[#f5e6c8] border-[#874b17] hover:border-[#ffd700]'
                  }`}
                >
                  {lever.label}
                </button>

                <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] mt-1 text-center italic">
                  {lever.sublabel}
                </span>
              </div>
            );
          })}
        </div>

        {/* Feedback display */}
        {feedback && (
          <div className="mt-6 p-3 rounded bg-[#1a0f09] border-2 border-[#d4af37] text-center animate-pulse">
            <span className="font-typewriter text-sm text-[#ffd700]">
              {feedback}
            </span>
          </div>
        )}

        {/* Status bar */}
        <div className="mt-6 pt-4 border-t border-[#4f270a] flex items-center justify-between text-xs font-mono-steampunk text-[#a8a9ad]">
          <span>IGNITION STATUS: {isWakingUp ? 'FIRING CYLINDERS...' : 'STANDBY'}</span>
          <span>CHASSIS GROUNDED: POSSIBLY</span>
        </div>
      </div>
    </div>
  );
};
