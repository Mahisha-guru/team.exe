import React, { useState, useEffect, useRef } from 'react';
import { sound } from '../../services/sound';
import { SirClankington } from '../SirClankington';
import { Flame, Wind, AlertTriangle } from 'lucide-react';

interface Level2Props {
  onSuccess: () => void;
  onExplode: () => void;
  attempts: number;
}

interface SafeZone {
  min: number;
  max: number;
  name: string;
}

const SAFE_ZONES: SafeZone[] = [
  { min: 45, max: 70, name: "NOMINAL VICTORIAN STEAM" },
  { min: 25, max: 50, name: "LOW-PRESSURE SIMMER" },
  { min: 60, max: 85, name: "HIGH-OCTANE BREW PRESSURE" },
  { min: 35, max: 65, name: "STANDARD COGSWORTH PARADOX" },
];

const TERRIBLE_ADVICE = [
  "More pressure means more success. Probably. Keep it near the red!",
  "Pro tip: If the boiler glows orange, it means the water is getting friendly.",
  "Never vent steam. That is pure British energy escaping into the atmosphere.",
  "Red zone merely denotes maximum enthusiasm. Proceed with haste.",
  "The gauge needle is shaking because it is excited for tea.",
];

export const Level2BoilerPanic: React.FC<Level2Props> = ({
  onSuccess,
  onExplode,
}) => {
  // Pressure state 0 to 100 PSI
  const [pressure, setPressure] = useState<number>(40);
  const [targetZoneIndex, setTargetZoneIndex] = useState<number>(0);
  const [cumulativeSeconds, setCumulativeSeconds] = useState<number>(0);
  const [warningNextZone, setWarningNextZone] = useState<boolean>(false);
  const [adviceIndex, setAdviceIndex] = useState<number>(0);
  const [isVenting, setIsVenting] = useState<boolean>(false);
  const [isStoking, setIsStoking] = useState<boolean>(false);
  const [temperature, setTemperature] = useState<number>(180); // Fahrenheit

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const pressureRef = useRef<number>(pressure);
  pressureRef.current = pressure;

  const currentZone = SAFE_ZONES[targetZoneIndex];
  const GOAL_SECONDS = 20;

  // Cycle bad advice
  useEffect(() => {
    const adviceInterval = setInterval(() => {
      setAdviceIndex(prev => (prev + 1) % TERRIBLE_ADVICE.length);
    }, 4500);
    return () => clearInterval(adviceInterval);
  }, []);

  // Periodic safe zone shifting
  useEffect(() => {
    const shiftInterval = setInterval(() => {
      // 2 seconds warning before shift
      setWarningNextZone(true);
      sound.playAlarm();

      setTimeout(() => {
        setTargetZoneIndex(prev => (prev + 1) % SAFE_ZONES.length);
        setWarningNextZone(false);
      }, 2000);
    }, 7000);

    return () => clearInterval(shiftInterval);
  }, []);

  // Main simulation tick (60 FPS / requestAnimationFrame or high precision interval)
  useEffect(() => {
    let lastTime = performance.now();
    let secondAccumulator = 0;

    const interval = setInterval(() => {
      const now = performance.now();
      const dt = (now - lastTime) / 1000;
      lastTime = now;

      setPressure(prev => {
        // Natural heat buildup
        let delta = 8.5 * dt;

        // User venting
        if (isVenting) {
          delta -= 32 * dt;
        }

        // User stoking
        if (isStoking) {
          delta += 28 * dt;
        }

        // Small jitter
        delta += (Math.random() - 0.5) * 1.5 * dt;

        let next = prev + delta;

        // Check explosion
        if (next >= 99.5) {
          sound.playExplosion();
          onExplode();
          return 100;
        }

        // Lower floor clamp
        if (next < 5) next = 5;

        return next;
      });

      // Update temperature
      setTemperature(Math.round(100 + pressureRef.current * 2.2));

      // Track cumulative safe zone seconds
      const curP = pressureRef.current;
      const inZone = curP >= currentZone.min && curP <= currentZone.max;

      if (inZone) {
        secondAccumulator += dt;
        if (secondAccumulator >= 0.2) {
          setCumulativeSeconds(prev => {
            const next = prev + secondAccumulator;
            if (next >= GOAL_SECONDS) {
              sound.playVictory();
              onSuccess();
            }
            return next;
          });
          secondAccumulator = 0;
        }
      }
    }, 50);

    return () => clearInterval(interval);
  }, [isVenting, isStoking, currentZone, onSuccess, onExplode]);

  // Render Victorian Pressure Gauge on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const radius = width * 0.42;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Outer brass rim
    const rimGrad = ctx.createRadialGradient(centerX, centerY, radius * 0.8, centerX, centerY, radius * 1.05);
    rimGrad.addColorStop(0, '#e5c158');
    rimGrad.addColorStop(0.5, '#b87333');
    rimGrad.addColorStop(1, '#4f270a');
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 1.05, 0, Math.PI * 2);
    ctx.fillStyle = rimGrad;
    ctx.fill();
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#2e1809';
    ctx.stroke();

    // Rivets around rim
    const rivetCount = 12;
    for (let i = 0; i < rivetCount; i++) {
      const angle = (i * Math.PI * 2) / rivetCount;
      const rx = centerX + Math.cos(angle) * (radius * 0.98);
      const ry = centerY + Math.sin(angle) * (radius * 0.98);
      ctx.beginPath();
      ctx.arc(rx, ry, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffd700';
      ctx.fill();
      ctx.strokeStyle = '#553b27';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // Inner parchment dial face
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.9, 0, Math.PI * 2);
    ctx.fillStyle = '#f7ecd5';
    ctx.fill();
    ctx.strokeStyle = '#874b17';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Dial arc angles: -140 deg to +140 deg (in radians: 0.72 PI to 2.28 PI)
    const startAngle = Math.PI * 0.75;
    const endAngle = Math.PI * 2.25;
    const totalAngle = endAngle - startAngle;

    // 1. Draw Safe Zone Arc
    const zoneStartAngle = startAngle + (currentZone.min / 100) * totalAngle;
    const zoneEndAngle = startAngle + (currentZone.max / 100) * totalAngle;

    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.72, zoneStartAngle, zoneEndAngle);
    ctx.lineWidth = 18;
    ctx.strokeStyle = '#22c55e'; // Bright green safe zone
    ctx.stroke();

    // 2. Draw Danger Red Arc (88% to 100%)
    const dangerStart = startAngle + 0.88 * totalAngle;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius * 0.72, dangerStart, endAngle);
    ctx.lineWidth = 18;
    ctx.strokeStyle = 'rgba(220, 38, 38, 0.8)'; // Redline danger
    ctx.stroke();

    // 3. Tick Marks & Numerals
    for (let p = 0; p <= 100; p += 10) {
      const angle = startAngle + (p / 100) * totalAngle;
      const isMajor = p % 20 === 0;
      const tickInner = isMajor ? radius * 0.6 : radius * 0.68;
      const tickOuter = radius * 0.78;

      const x1 = centerX + Math.cos(angle) * tickInner;
      const y1 = centerY + Math.sin(angle) * tickInner;
      const x2 = centerX + Math.cos(angle) * tickOuter;
      const y2 = centerY + Math.sin(angle) * tickOuter;

      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.strokeStyle = '#302018';
      ctx.lineWidth = isMajor ? 2.5 : 1.2;
      ctx.stroke();

      if (isMajor) {
        const textRadius = radius * 0.5;
        const tx = centerX + Math.cos(angle) * textRadius;
        const ty = centerY + Math.sin(angle) * textRadius + 4;
        ctx.fillStyle = '#302018';
        ctx.font = 'bold 11px Courier, monospace';
        ctx.textAlign = 'center';
        ctx.fillText(p.toString(), tx, ty);
      }
    }

    // Dial Brand Text
    ctx.fillStyle = '#874b17';
    ctx.font = 'bold 9px "Cinzel", serif';
    ctx.textAlign = 'center';
    ctx.fillText('COGSWORTH THERMODYNAMICS', centerX, centerY - radius * 0.28);
    ctx.fillText('PSI × 100', centerX, centerY + radius * 0.38);

    // 4. Moving Needle
    const clampedPressure = Math.max(0, Math.min(100, pressure));
    const needleAngle = startAngle + (clampedPressure / 100) * totalAngle;

    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.rotate(needleAngle);

    // Needle shadow
    ctx.beginPath();
    ctx.moveTo(-4, -radius * 0.82);
    ctx.lineTo(4, -radius * 0.82);
    ctx.lineTo(6, 12);
    ctx.lineTo(-6, 12);
    ctx.closePath();
    ctx.fillStyle = '#b22222';
    ctx.fill();

    // Center brass cap
    ctx.beginPath();
    ctx.arc(0, 0, 10, 0, Math.PI * 2);
    ctx.fillStyle = '#d4af37';
    ctx.fill();
    ctx.strokeStyle = '#4f270a';
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }, [pressure, currentZone]);

  const handleStartVent = () => {
    setIsVenting(true);
    sound.playSteam(0.6, 0.7);
  };
  const handleStopVent = () => {
    setIsVenting(false);
  };

  const handleStartStoke = () => {
    setIsStoking(true);
    sound.playClick(0.7);
  };
  const handleStopStoke = () => {
    setIsStoking(false);
  };

  const inSafeZone = pressure >= currentZone.min && pressure <= currentZone.max;

  return (
    <div className="w-full max-w-4xl mx-auto space-y-5">
      {/* Top Banner */}
      <div className="bg-[#2a1a11] border-2 border-[#b87333] rounded-lg p-3.5 shadow-xl relative text-center">
        <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
          Stage II: Thermodynamic Balancing
        </span>
        <h2 className="font-victorian text-2xl font-bold text-[#ffd700]">
          BOILER PANIC
        </h2>
        <p className="font-typewriter text-xs text-[#f5e6c8] max-w-xl mx-auto italic mt-1">
          Maintain steam pressure in the shifting safe zone for 20 cumulative seconds.
          Whatever you do, DO NOT reach 100 PSI or the boiler will disassemble aggressively.
        </p>
      </div>

      {/* Sir Clankington & Terrible Machine Advice */}
      <SirClankington level={2} customMessage={TERRIBLE_ADVICE[adviceIndex]} />

      {/* Main Interactive Boiler Dashboard */}
      <div className="bg-iron-dark border-4 border-[#874b17] rounded-xl p-6 shadow-2xl relative">
        {/* Shifting zone alert banner */}
        {warningNextZone && (
          <div className="mb-4 p-2 bg-[#b22222] text-white rounded border border-[#ffd700] flex items-center justify-center gap-2 animate-bounce">
            <AlertTriangle size={18} />
            <span className="font-victorian text-xs font-bold tracking-wider">
              WARNING: THERMODYNAMIC FLUCTUATION! SAFE ZONE RELOCATING IN 2 SECONDS!
            </span>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          {/* Left Column: Canvas Gauge */}
          <div className="flex flex-col items-center justify-center">
            <div className="relative">
              <canvas
                ref={canvasRef}
                width={300}
                height={300}
                className="drop-shadow-2xl"
              />
              {/* Pressure status badge */}
              <div
                className={`absolute bottom-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded text-xs font-mono-steampunk font-bold border ${
                  inSafeZone
                    ? 'bg-green-900/90 text-green-300 border-green-500 shadow-lg'
                    : pressure > currentZone.max
                    ? 'bg-red-900/90 text-red-300 border-red-500 animate-pulse'
                    : 'bg-amber-900/90 text-amber-300 border-amber-500'
                }`}
              >
                {inSafeZone ? 'PRESSURE OPTIMAL' : pressure > currentZone.max ? 'CRITICAL HIGH' : 'PRESSURE LOW'} ({Math.round(pressure)} PSI)
              </div>
            </div>

            <div className="mt-2 text-center">
              <span className="text-xs font-mono-steampunk text-[#ffd700]">
                ACTIVE SAFE ZONE: {currentZone.min} - {currentZone.max} PSI
              </span>
              <p className="text-[10px] text-[#a8a9ad] font-mono-steampunk">
                Classification: {currentZone.name}
              </p>
            </div>
          </div>

          {/* Right Column: Controls & Metrics */}
          <div className="space-y-5">
            {/* 20-Second Cumulative Progress Bar */}
            <div className="p-3 bg-[#1e130c] border border-[#874b17] rounded-lg">
              <div className="flex items-center justify-between text-xs font-victorian font-bold text-[#ffd700] mb-1">
                <span>STABILIZATION PROGRESS</span>
                <span>{cumulativeSeconds.toFixed(1)}s / {GOAL_SECONDS}s</span>
              </div>
              <div className="w-full h-4 bg-[#120a06] rounded-xs border border-[#4f270a] overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-amber-600 via-green-600 to-emerald-400 transition-all duration-150"
                  style={{ width: `${Math.min(100, (cumulativeSeconds / GOAL_SECONDS) * 100)}%` }}
                />
              </div>
              <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] mt-1 block">
                {inSafeZone ? '⚡ Meter charging...' : '⚠️ Outside safe zone; stabilization paused.'}
              </span>
            </div>

            {/* Temperature & Water Vitals */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-2.5 bg-[#190f0a] border border-[#6d4018] rounded text-center">
                <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">
                  CORE TEMPERATURE
                </span>
                <span className="font-mono-steampunk text-lg font-bold text-[#e69138]">
                  {temperature}°F
                </span>
              </div>
              <div className="p-2.5 bg-[#190f0a] border border-[#6d4018] rounded text-center">
                <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">
                  KETTLE AGITATION
                </span>
                <span className="font-mono-steampunk text-lg font-bold text-[#ffd700]">
                  {pressure > 85 ? 'SEVERELY MIFFED' : 'POLITELY BOILING'}
                </span>
              </div>
            </div>

            {/* Tactile Control Buttons */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              {/* Stoke Furnace Button */}
              <button
                onMouseDown={handleStartStoke}
                onMouseUp={handleStopStoke}
                onTouchStart={handleStartStoke}
                onTouchEnd={handleStopStoke}
                className="py-4 px-3 rounded-lg bg-gradient-to-b from-[#874b17] to-[#4f270a] hover:from-[#a05a1e] hover:to-[#63330f] border-2 border-[#d4af37] text-[#ffd700] font-victorian font-bold text-xs shadow-lg active:scale-95 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer select-none"
              >
                <Flame size={20} className="text-orange-400 animate-pulse" />
                <span>STOKE FURNACE</span>
                <span className="text-[9px] font-mono-steampunk text-[#e69138] font-normal">
                  (HOLD to raise PSI)
                </span>
              </button>

              {/* Vent Steam Valve Button */}
              <button
                onMouseDown={handleStartVent}
                onMouseUp={handleStopVent}
                onTouchStart={handleStartVent}
                onTouchEnd={handleStopVent}
                className="py-4 px-3 rounded-lg bg-gradient-to-b from-[#b22222] to-[#681111] hover:from-[#c52b2b] hover:to-[#7f1818] border-2 border-[#ffd700] text-white font-victorian font-bold text-xs shadow-lg active:scale-95 transition-all flex flex-col items-center justify-center gap-1 cursor-pointer select-none"
              >
                <Wind size={20} className="text-cyan-200" />
                <span>VENT VALVE</span>
                <span className="text-[9px] font-mono-steampunk text-cyan-200 font-normal">
                  (HOLD to vent PSI)
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
