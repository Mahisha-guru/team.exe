import React, { useState, useEffect } from 'react';
import { sound } from '../../services/sound';
import { SirClankington } from '../SirClankington';
import { Key, Wind, Flame, CheckCircle, Coffee, Sparkles, AlertTriangle } from 'lucide-react';

interface Level5Props {
  onSuccess: () => void;
  onExplode: () => void;
}

export const Level5FinalCupOfTea: React.FC<Level5Props> = ({ onSuccess, onExplode }) => {
  // 5 Steps State
  const [step1KeyTurned, setStep1KeyTurned] = useState<boolean>(false);
  const [step2Pressure, setStep2Pressure] = useState<number>(50); // Target: 65 - 75 for 5 seconds
  const [step2HoldSeconds, setStep2HoldSeconds] = useState<number>(0);
  const [step2Completed, setStep2Completed] = useState<boolean>(false);
  const [step3ValveReleased, setStep3ValveReleased] = useState<boolean>(false);
  const [step4TeaLeavesCount, setStep4TeaLeavesCount] = useState<number>(0); // Need 4 tea leaf deposits
  const [step4Completed, setStep4Completed] = useState<boolean>(false);
  const [step5PlungerReady, setStep5PlungerReady] = useState<boolean>(false);

  // Cinematic Brewing Sequence
  const [isBrewing, setIsBrewing] = useState<boolean>(false);
  const [brewCountdown, setBrewCountdown] = useState<number>(5);
  const [brewLog, setBrewLog] = useState<string>('');
  const [clankMessage, setClankMessage] = useState<string>(
    "We stand on the precipice of destiny. Five distinct points of mechanical failure await your gentle touch."
  );

  // Pressure holding logic for Step 2
  useEffect(() => {
    if (!step1KeyTurned || step2Completed) return;

    const interval = setInterval(() => {
      setStep2Pressure(prev => {
        // Natural drift upwards
        let next = prev + 1.2 + (Math.random() - 0.5) * 2;
        if (next >= 99) {
          sound.playExplosion();
          onExplode();
          return 100;
        }
        return Math.max(10, next);
      });

      // Target safe zone: 60 - 80 PSI
      if (step2Pressure >= 60 && step2Pressure <= 80) {
        setStep2HoldSeconds(prev => {
          const next = prev + 0.2;
          if (next >= 5) {
            setStep2Completed(true);
            sound.playStamp(true);
            setClankMessage("Boiler stabilized! Quickly disengage the secondary safety valve before it cools!");
          }
          return next;
        });
      } else {
        setStep2HoldSeconds(0); // reset if lost
      }
    }, 200);

    return () => clearInterval(interval);
  }, [step1KeyTurned, step2Completed, step2Pressure, onExplode]);

  // Check Step 5 readiness
  useEffect(() => {
    if (step1KeyTurned && step2Completed && step3ValveReleased && step4Completed) {
      setStep5PlungerReady(true);
      setClankMessage("ALL SYSTEMS PRIMED! Brace yourself and depress the Master Brew Plunger!");
    }
  }, [step1KeyTurned, step2Completed, step3ValveReleased, step4Completed]);

  // Step 1: Turn Ignition Key
  const handleTurnKey = () => {
    if (step1KeyTurned) return;
    sound.playClick(0.7);
    sound.playGear('right');
    setStep1KeyTurned(true);
    setClankMessage("Ignition established! Now maintain steam between 60 and 80 PSI for 5 full seconds.");
  };

  // Step 2: Stoke / Vent
  const handleStoke = () => {
    sound.playClick(1.2);
    setStep2Pressure(p => Math.min(98, p + 6));
  };
  const handleVent = () => {
    sound.playSteam(0.3, 0.6);
    setStep2Pressure(p => Math.max(10, p - 8));
  };

  // Step 3: Release Valve
  const handleReleaseValve = () => {
    if (!step2Completed || step3ValveReleased) return;
    sound.playSteam(0.8, 0.9);
    sound.playClick(1.5);
    setStep3ValveReleased(true);
    setClankMessage("Pressure diverted to infusion chamber! Now deposit precisely four spoonfuls of tea leaves.");
  };

  // Step 4: Deposit Tea Leaves
  const handleAddTeaLeaf = () => {
    if (!step3ValveReleased || step4Completed) return;
    sound.playClick(1.6);
    const next = step4TeaLeavesCount + 1;
    setStep4TeaLeavesCount(next);
    if (next >= 4) {
      setStep4Completed(true);
      sound.playStamp(true);
      setClankMessage("Tea hopper loaded with imperial leaves! All that remains is the Master Plunger!");
    }
  };

  // Step 5: Press Master Plunger & Run Dramatic Sequence!
  const handleMasterBrew = () => {
    if (!step5PlungerReady || isBrewing) return;
    setIsBrewing(true);
    sound.playAlarm();
    sound.playSteam(3.0, 1.0);

    let count = 5;
    setBrewCountdown(count);

    const logs = [
      "BOILER AT MAXIMUM THEORETICAL VIBRATION...",
      "WATER MOLECULES FORCED THROUGH HIGH-VELOCITY COPPER TUBES...",
      "TEA LEAVES COLLIDING WITH THERMAL TURBULENCE...",
      "FINAL DROPLET CONDENSING IN CHAMBER OMEGA...",
      "EXTRACTION COMPLETE: TOTAL FAILURE TO PRODUCE REASONABLE VOLUME...",
    ];

    setBrewLog(logs[0]);

    const timer = setInterval(() => {
      count -= 1;
      setBrewCountdown(count);
      sound.playClick(1.0 + (5 - count) * 0.2);

      if (count > 0) {
        setBrewLog(logs[5 - count]);
      } else {
        clearInterval(timer);
        // Sudden dramatic stop, tiny cup emerges!
        sound.playTeaDrop();
        setTimeout(() => {
          sound.playVictory();
          onSuccess();
        }, 1500);
      }
    }, 1000);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-5">
      {/* Top Banner */}
      <div className="bg-[#2a1a11] border-2 border-[#b87333] rounded-lg p-3.5 shadow-xl relative text-center">
        <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
          Stage V: The Grand Convergence
        </span>
        <h2 className="font-victorian text-2xl font-bold text-[#ffd700]">
          THE FINAL CUP OF TEA
        </h2>
        <p className="font-typewriter text-xs text-[#f5e6c8] max-w-xl mx-auto italic mt-1">
          Perform the five critical procedures in sequence. All mechanical systems are armed.
          May the Queen have mercy on our boiler gaskets.
        </p>
      </div>

      {/* Sir Clankington */}
      <SirClankington level={5} customMessage={clankMessage} />

      {/* Main Multi-System Console */}
      <div className="bg-iron-dark border-4 border-[#874b17] rounded-xl p-6 shadow-2xl relative overflow-hidden">
        {/* If dramatic cinematic sequence running */}
        {isBrewing ? (
          <div className="py-12 flex flex-col items-center justify-center text-center space-y-6 animate-pulse">
            <div className="w-24 h-24 rounded-full bg-[#b22222] border-4 border-[#ffd700] flex items-center justify-center text-4xl font-victorian font-black text-white glow-red shadow-2xl">
              {brewCountdown}
            </div>

            <div className="space-y-2">
              <h3 className="font-victorian text-2xl font-bold text-[#ffd700]">
                HYPER-PRESSURE EXTRACTION IN PROGRESS!
              </h3>
              <p className="font-typewriter text-sm text-[#e69138]">
                {brewLog}
              </p>
            </div>

            <div className="flex gap-2">
              <div className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
              <div className="w-3 h-3 rounded-full bg-yellow-500 animate-ping delay-100" />
              <div className="w-3 h-3 rounded-full bg-orange-500 animate-ping delay-200" />
            </div>

            <span className="text-xs font-mono-steampunk text-[#a8a9ad] italic">
              Estimated energy consumed: 400 metric tons of bituminous coal.
            </span>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Steps Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* STEP 1: Main Ignition Key */}
              <div className={`p-4 rounded-lg border-2 transition-all ${
                step1KeyTurned ? 'bg-[#1b261b] border-green-700' : 'bg-[#22150d] border-[#874b17]'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-victorian text-xs font-bold text-[#ffd700]">
                    STEP 1: MASTER IGNITION
                  </span>
                  {step1KeyTurned && <CheckCircle size={16} className="text-green-500" />}
                </div>

                <p className="text-xs font-mono-steampunk text-[#a8a9ad] mb-3">
                  Turn the forged brass key to energize auxiliary steam pipes.
                </p>

                <button
                  disabled={step1KeyTurned}
                  onClick={handleTurnKey}
                  className={`w-full py-2.5 px-3 rounded font-victorian text-xs font-bold border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    step1KeyTurned
                      ? 'bg-green-900/40 text-green-300 border-green-700'
                      : 'bg-brass-plate text-black border-[#ffd700] hover:brightness-110 shadow'
                  }`}
                >
                  <Key size={16} />
                  <span>{step1KeyTurned ? 'IGNITION ENGAGED' : 'TURN MASTER KEY'}</span>
                </button>
              </div>

              {/* STEP 2: Balance Steam Pressure */}
              <div className={`p-4 rounded-lg border-2 transition-all ${
                !step1KeyTurned
                  ? 'opacity-50 pointer-events-none bg-[#190f0a] border-[#442510]'
                  : step2Completed
                  ? 'bg-[#1b261b] border-green-700'
                  : 'bg-[#22150d] border-[#874b17]'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-victorian text-xs font-bold text-[#ffd700]">
                    STEP 2: STABILIZE PRESSURE (60-80 PSI)
                  </span>
                  {step2Completed && <CheckCircle size={16} className="text-green-500" />}
                </div>

                <div className="flex items-center justify-between text-xs font-mono-steampunk mb-2">
                  <span className="text-[#ffd700]">PSI: {Math.round(step2Pressure)}</span>
                  <span className="text-green-400">Hold: {step2HoldSeconds.toFixed(1)}s / 5.0s</span>
                </div>

                {/* Progress bar */}
                <div className="w-full h-2 bg-[#120a06] rounded-full mb-3 overflow-hidden">
                  <div
                    className="h-full bg-green-500 transition-all duration-150"
                    style={{ width: `${(step2HoldSeconds / 5) * 100}%` }}
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    disabled={step2Completed || !step1KeyTurned}
                    onClick={handleStoke}
                    className="py-1.5 px-2 rounded bg-[#4f270a] border border-[#d4af37] text-xs font-victorian font-bold text-[#ffd700] hover:bg-[#683611] flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Flame size={14} />
                    <span>+ STOKE</span>
                  </button>
                  <button
                    disabled={step2Completed || !step1KeyTurned}
                    onClick={handleVent}
                    className="py-1.5 px-2 rounded bg-[#b22222] border border-[#ffd700] text-xs font-victorian font-bold text-white hover:bg-[#cd2b2b] flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Wind size={14} />
                    <span>- VENT</span>
                  </button>
                </div>
              </div>

              {/* STEP 3: Disengage Safety Lockout */}
              <div className={`p-4 rounded-lg border-2 transition-all ${
                !step2Completed
                  ? 'opacity-50 pointer-events-none bg-[#190f0a] border-[#442510]'
                  : step3ValveReleased
                  ? 'bg-[#1b261b] border-green-700'
                  : 'bg-[#22150d] border-[#874b17]'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-victorian text-xs font-bold text-[#ffd700]">
                    STEP 3: SAFETY VALVE LOCKOUT
                  </span>
                  {step3ValveReleased && <CheckCircle size={16} className="text-green-500" />}
                </div>

                <p className="text-xs font-mono-steampunk text-[#a8a9ad] mb-3">
                  Trip the counter-weighted brass lever to direct steam to the infuser.
                </p>

                <button
                  disabled={!step2Completed || step3ValveReleased}
                  onClick={handleReleaseValve}
                  className={`w-full py-2.5 px-3 rounded font-victorian text-xs font-bold border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    step3ValveReleased
                      ? 'bg-green-900/40 text-green-300 border-green-700'
                      : 'bg-copper-plate text-white border-[#ffd700] hover:brightness-110 shadow'
                  }`}
                >
                  <Wind size={16} />
                  <span>{step3ValveReleased ? 'VALVE DISENGAGED' : 'TRIP SAFETY VALVE'}</span>
                </button>
              </div>

              {/* STEP 4: Insert Tea Leaves */}
              <div className={`p-4 rounded-lg border-2 transition-all ${
                !step3ValveReleased
                  ? 'opacity-50 pointer-events-none bg-[#190f0a] border-[#442510]'
                  : step4Completed
                  ? 'bg-[#1b261b] border-green-700'
                  : 'bg-[#22150d] border-[#874b17]'
              }`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-victorian text-xs font-bold text-[#ffd700]">
                    STEP 4: FEED TEA HOPPER
                  </span>
                  {step4Completed && <CheckCircle size={16} className="text-green-500" />}
                </div>

                <p className="text-xs font-mono-steampunk text-[#a8a9ad] mb-1">
                  Deposit 4 scoops of dried Camellia Sinensis into the intake.
                </p>

                <div className="flex items-center justify-between text-xs font-mono-steampunk mb-2">
                  <span className="text-[#ffd700]">SCOOPS LOADED: {step4TeaLeavesCount} / 4</span>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4].map(idx => (
                      <span key={idx} className={idx <= step4TeaLeavesCount ? 'text-amber-400' : 'text-[#442510]'}>
                        🍃
                      </span>
                    ))}
                  </div>
                </div>

                <button
                  disabled={!step3ValveReleased || step4Completed}
                  onClick={handleAddTeaLeaf}
                  className={`w-full py-2.5 px-3 rounded font-victorian text-xs font-bold border transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    step4Completed
                      ? 'bg-green-900/40 text-green-300 border-green-700'
                      : 'bg-[#3b2315] hover:bg-[#52331d] text-[#ffd700] border-[#d4af37] shadow'
                  }`}
                >
                  <Coffee size={16} />
                  <span>{step4Completed ? 'HOPPER SATURATED' : 'DEPOSIT TEA LEAF'}</span>
                </button>
              </div>
            </div>

            {/* STEP 5: MASTER BREW PLUNGER */}
            <div className={`p-6 rounded-xl border-4 text-center transition-all ${
              step5PlungerReady
                ? 'bg-gradient-to-b from-[#2e150b] to-[#1a0a05] border-[#ffd700] shadow-2xl glow-amber'
                : 'bg-[#190f0a] border-[#442510] opacity-40 pointer-events-none'
            }`}>
              <span className="text-xs font-mono-steampunk text-[#ffd700] tracking-widest uppercase block mb-1">
                Final Directive: The Culmination of Science
              </span>
              <h3 className="font-victorian text-xl font-bold text-white mb-2">
                THE MASTER INFUSION PLUNGER
              </h3>
              <p className="font-typewriter text-xs text-[#d4af37] max-w-md mx-auto mb-4">
                All safety interlocks have been satisfied. Depress this button to unleash 500 atmospheres of boiling steam.
              </p>

              <button
                disabled={!step5PlungerReady || isBrewing}
                onClick={handleMasterBrew}
                className="py-4 px-8 rounded-full bg-gradient-to-r from-[#b22222] via-[#d4af37] to-[#b22222] hover:brightness-125 border-4 border-[#ffd700] text-black font-victorian font-black text-base shadow-2xl active:scale-95 transition-all flex items-center gap-3 mx-auto cursor-pointer"
              >
                <Sparkles size={20} className="animate-spin" />
                <span>COMMENCE TITANIC BREW SEQUENCE</span>
                <Sparkles size={20} className="animate-spin" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
