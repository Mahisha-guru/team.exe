import React from 'react';
import { Volume2, VolumeX, Pause, RotateCcw, Award, Trophy } from 'lucide-react';
import { sound } from '../services/sound';
import { FakeProgressBar } from './FakeProgressBar';

interface HeaderHUDProps {
  level: number;
  levelTitle: string;
  levelSubtitle: string;
  attempts: number;
  timeElapsed: number;
  isPaused: boolean;
  isMuted: boolean;
  onTogglePause: () => void;
  onToggleSound: () => void;
  onRestartLevel: () => void;
  onOpenAchievements: () => void;
  onOpenLeaderboard: () => void;
  unlockedCount: number;
  totalAchievements: number;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  level,
  levelTitle,
  levelSubtitle,
  attempts,
  timeElapsed,
  isPaused,
  isMuted,
  onTogglePause,
  onToggleSound,
  onRestartLevel,
  onOpenAchievements,
  onOpenLeaderboard,
  unlockedCount,
  totalAchievements,
}) => {
  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  return (
    <header className="w-full bg-[#271911] border-b-4 border-[#874b17] shadow-xl relative z-20">
      {/* Decorative brass rivet row */}
      <div className="absolute top-1 left-2 flex gap-4 pointer-events-none">
        <div className="rivet" />
        <div className="rivet" />
      </div>
      <div className="absolute top-1 right-2 flex gap-4 pointer-events-none">
        <div className="rivet" />
        <div className="rivet" />
      </div>

      <div className="max-w-6xl mx-auto px-4 py-2.5">
        {/* Main top bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Machine Branding & Current Stage */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-md bg-copper-plate border-2 border-[#d4af37] flex items-center justify-center shadow-md">
              <span className="text-xl">☕</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-victorian text-lg md:text-xl font-black text-[#ffd700] tracking-wider drop-shadow">
                  STEAM.exe
                </h1>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#4f270a] border border-[#d4af37] text-[#ffd700] font-mono-steampunk font-bold">
                  v18.89-VICTORIAN
                </span>
              </div>
              <p className="text-xs font-mono-steampunk text-[#d4af37]/80">
                Stage {level}: <span className="text-white font-bold">{levelTitle}</span> – {levelSubtitle}
              </p>
            </div>
          </div>

          {/* Center Stats: Timer and Attempts/Fuses */}
          <div className="flex items-center gap-4 bg-[#1a110a] px-4 py-1.5 rounded-lg border border-[#874b17]">
            {/* Attempts (Boiler Pressure Fuses) */}
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-victorian font-bold text-[#a8a9ad]">FUSES:</span>
              <div className="flex gap-1" title={`${attempts} Mechanical attempts remaining`}>
                {[1, 2, 3].map(index => {
                  const active = index <= attempts;
                  return (
                    <div
                      key={index}
                      className={`w-4 h-6 rounded-t-sm border transition-all ${
                        active
                          ? 'bg-amber-500 border-amber-300 glow-amber'
                          : 'bg-[#302018] border-[#553b27] opacity-40'
                      }`}
                    />
                  );
                })}
              </div>
            </div>

            <div className="h-5 w-px bg-[#4f270a]" />

            {/* Stopwatch */}
            <div className="flex items-center gap-1.5 font-mono-steampunk text-sm">
              <span className="text-xs text-[#a8a9ad]">TIME:</span>
              <span className="text-[#ffd700] font-bold tracking-widest">
                {formatTime(timeElapsed)}
              </span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2">
            {/* Imperial Leaderboard Button */}
            <button
              onClick={onOpenLeaderboard}
              className="p-2 rounded bg-[#332014] border border-[#b87333] hover:border-[#ffd700] text-[#ffd700] hover:bg-[#4a2e1d] transition-all relative cursor-pointer"
              title="Imperial Telegraph Leaderboard (Firestore)"
            >
              <Trophy size={18} />
            </button>

            {/* Achievements button */}
            <button
              onClick={onOpenAchievements}
              className="p-2 rounded bg-[#332014] border border-[#b87333] hover:border-[#ffd700] text-[#ffd700] hover:bg-[#4a2e1d] transition-all relative cursor-pointer"
              title="Imperial Patents & Medals"
            >
              <Award size={18} />
              <span className="absolute -top-1.5 -right-1.5 bg-[#b22222] text-white text-[9px] font-bold rounded-full w-4 h-4 flex items-center justify-center border border-[#ffd700]">
                {unlockedCount}
              </span>
            </button>

            {/* Restart Level */}
            <button
              onClick={() => {
                sound.playClick();
                onRestartLevel();
              }}
              className="p-2 rounded bg-[#332014] border border-[#b87333] hover:border-[#ffd700] text-[#ffd700] hover:bg-[#4a2e1d] transition-all cursor-pointer"
              title="Restart Level"
            >
              <RotateCcw size={18} />
            </button>

            {/* Sound Toggle */}
            <button
              onClick={() => {
                onToggleSound();
              }}
              className="p-2 rounded bg-[#332014] border border-[#b87333] hover:border-[#ffd700] text-[#ffd700] hover:bg-[#4a2e1d] transition-all cursor-pointer"
              title={isMuted ? 'Unmute Sound FX' : 'Mute Sound FX'}
            >
              {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
            </button>

            {/* Pause / Resume */}
            <button
              onClick={() => {
                sound.playClick();
                onTogglePause();
              }}
              className="px-3 py-1.5 rounded bg-brass-plate text-[#1c120c] font-victorian font-bold text-xs border border-[#ffd700] hover:brightness-110 shadow-sm flex items-center gap-1 cursor-pointer"
            >
              <Pause size={14} />
              <span>{isPaused ? 'RESUME' : 'PAUSE'}</span>
            </button>
          </div>
        </div>

        {/* Bottom row: The Deliberately Backwards Fake Progress Bar */}
        <div className="mt-2">
          <FakeProgressBar realLevel={level} />
        </div>
      </div>
    </header>
  );
};
