import React, { useState, useEffect } from 'react';
import { sound } from '../services/sound';

interface SirClankingtonProps {
  level: number;
  customMessage?: string;
  onPoke?: () => void;
}

const DEFAULT_LEVEL_QUOTES: Record<number, string[]> = {
  1: [
    "Excellent! You've successfully stared at five levers. Society advances.",
    "Have you considered simply purchasing tea from the corner apothecary?",
    "That lever looks particularly unhelpful. I strongly recommend touching it.",
    "Do remember: reading the labels will only confuse you further.",
  ],
  2: [
    "More pressure means more success. Probably. I am an automaton, not a physicist.",
    "Notice how the safe zone is moving? That is called 'Dynamic Inconvenience'.",
    "If the boiler ruptures, please ensure your will leaves everything to the crown.",
    "Fascinating! You are within 3 PSI of total vaporization.",
  ],
  3: [
    "The gears are jamming. Truly, Charles Babbage wept so that we might suffer.",
    "Every ten seconds, rotation reverses. The patent office deemed this 'character-building'.",
    "Left is right, right is left. Or perhaps both are wrong. Do ponder that.",
    "I could align them in four milliseconds, but my union contract forbids assisting humans.",
  ],
  4: [
    "Ah, Form 42-B. The highest achievement of the British Empire: weaponized paperwork.",
    "The water has not yet consented. You wouldn't want to bully hydrogen atoms, would you?",
    "Remember: Her Majesty requires that your kettle possess unwavering patriotism.",
    "Bureaucracy is like steam: suffocating, noisy, and completely unnecessary.",
  ],
  5: [
    "We are moments away from producing seven millilitres of tepid water. Brace yourself!",
    "All five systems are groaning under immense mechanical absurdity. Beautiful.",
    "One small cup for you, one catastrophic waste of coal for mankind.",
    "Warning: The machine is functioning correctly. This is highly unusual and deeply concerning.",
  ],
};

const POKE_QUOTES = [
  "Do not poke the brasswork, peasant. I was polished this morning.",
  "Ouch. My chassis is rated for steam, not unprovoked insolence.",
  "Your competence has been reported to management.",
  "Poking me does not increase the kettle's temperature, unfortunately.",
  "I am filing a formal grievance with the Automaton Guild.",
];

export const SirClankington: React.FC<SirClankingtonProps> = ({
  level,
  customMessage,
  onPoke,
}) => {
  const [currentQuote, setCurrentQuote] = useState<string>('');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [monocleAngle, setMonocleAngle] = useState(0);

  // Set message when level changes or custom message provided
  useEffect(() => {
    if (customMessage) {
      setCurrentQuote(customMessage);
      triggerSpeech();
    } else {
      const quotes = DEFAULT_LEVEL_QUOTES[level] || DEFAULT_LEVEL_QUOTES[1];
      const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
      setCurrentQuote(randomQuote);
      triggerSpeech();
    }
  }, [level, customMessage]);

  const triggerSpeech = () => {
    setIsSpeaking(true);
    setMonocleAngle(prev => (prev === 0 ? 15 : 0));
    sound.playRobotTalk();
    const timer = setTimeout(() => {
      setIsSpeaking(false);
    }, 600);
    return () => clearTimeout(timer);
  };

  const handlePoke = () => {
    const quote = POKE_QUOTES[Math.floor(Math.random() * POKE_QUOTES.length)];
    setCurrentQuote(quote);
    triggerSpeech();
    if (onPoke) onPoke();
  };

  return (
    <div className="flex items-start gap-4 p-3 rounded-lg bg-[#241710] border-2 border-[#b87333] shadow-md relative overflow-hidden">
      {/* Background steam gears decorative */}
      <div className="absolute -right-4 -bottom-4 opacity-10 pointer-events-none text-6xl select-none">
        ⚙️
      </div>

      {/* Robot Avatar */}
      <div 
        onClick={handlePoke}
        title="Sir Clankington Mk. II (Click to poke)"
        className="cursor-pointer group flex-shrink-0 flex flex-col items-center relative"
      >
        {/* Steam exhaust puff from top chimney */}
        <div className="flex items-center justify-center -mb-1">
          <div className="w-2.5 h-3 bg-[#874b17] border border-[#d4af37] rounded-t-sm relative">
            <span className="absolute -top-3 left-0 text-[10px] animate-bounce opacity-70">
              💨
            </span>
          </div>
        </div>

        {/* Head chassis */}
        <div className="w-14 h-14 rounded-md bg-brass-plate border-2 border-[#685108] shadow-inner flex flex-col items-center justify-between p-1.5 relative group-hover:scale-105 transition-transform">
          {/* Rivets */}
          <div className="absolute top-0.5 left-0.5 rivet scale-75" />
          <div className="absolute top-0.5 right-0.5 rivet scale-75" />
          <div className="absolute bottom-0.5 left-0.5 rivet scale-75" />
          <div className="absolute bottom-0.5 right-0.5 rivet scale-75" />

          {/* Eyes row with monocle */}
          <div className="flex items-center justify-around w-full mt-1">
            {/* Left Eye */}
            <div className="w-3.5 h-3.5 rounded-full bg-[#1c120c] border border-[#d4af37] flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-[#e69138] glow-amber" />
            </div>

            {/* Right Eye with Monocle */}
            <div 
              className="w-4 h-4 rounded-full bg-[#1c120c] border-2 border-[#ffd700] flex items-center justify-center relative transition-transform duration-300"
              style={{ transform: `rotate(${monocleAngle}deg)` }}
            >
              <div className="w-2 h-2 rounded-full bg-[#ffd700] glow-amber" />
              {/* Monocle chain */}
              <div className="absolute -bottom-2 -right-1 w-2 h-2 border-r border-b border-[#ffd700] rounded-br-full" />
            </div>
          </div>

          {/* Mechanical Talking Mouth */}
          <div className="w-8 h-2 bg-[#1c120c] rounded-xs border border-[#874b17] flex items-center justify-center overflow-hidden">
            <div 
              className={`w-full bg-[#e69138] transition-all duration-100 ${
                isSpeaking ? 'h-1.5 opacity-90' : 'h-0.5 opacity-40'
              }`}
            />
          </div>
        </div>

        <span className="text-[9px] font-mono-steampunk text-[#d4af37] tracking-wider mt-1 text-center font-bold">
          SIR CLANKINGTON
        </span>
      </div>

      {/* Speech dialogue container */}
      <div className="flex-1 min-w-0 flex flex-col justify-center">
        <div className="flex items-center justify-between gap-2 mb-1">
          <span className="text-xs font-victorian font-bold text-[#ffd700] tracking-wide">
            Automaton Commentary:
          </span>
          <button
            onClick={handlePoke}
            className="text-[10px] text-[#d4af37] hover:text-[#fff] underline opacity-70 hover:opacity-100 cursor-pointer"
          >
            Poke Automaton
          </button>
        </div>

        <p className="font-typewriter text-sm text-[#f5e6c8] leading-relaxed italic bg-[#1a100a] p-2 rounded border border-[#874b17]/60 shadow-inner">
          "{currentQuote}"
        </p>
      </div>
    </div>
  );
};
