import React, { useEffect } from 'react';
import { sound } from '../services/sound';
import { ArrowRight, CheckCircle2, Cog } from 'lucide-react';

interface LevelTransitionScreenProps {
  completedLevel: number;
  nextLevel: number;
  nextLevelTitle: string;
  nextLevelSubtitle: string;
  onProceed: () => void;
}

const TRANSITION_FLAVORS: Record<number, string> = {
  1: "The primary furnace is roaring! Soot now coats the parlor wallpaper, but the machine is officially awake.",
  2: "Thermodynamics survived! The boiler is groaning at high pressure and five rivets have shot into the garden.",
  3: "Mechanical transmission locked! The gears are turning in harmony, defying Her Majesty's inverted torque decree.",
  4: "Her Majesty's Ministry has yielded! Form 42-B has been duly stamped, granting full constitutional right to brew.",
};

export const LevelTransitionScreen: React.FC<LevelTransitionScreenProps> = ({
  completedLevel,
  nextLevel,
  nextLevelTitle,
  nextLevelSubtitle,
  onProceed,
}) => {
  useEffect(() => {
    sound.playSteam(0.6, 0.5);
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto my-auto p-4 animate-in fade-in zoom-in-95 duration-300">
      <div className="bg-[#241710] border-4 border-[#874b17] rounded-xl p-6 sm:p-8 shadow-2xl text-center space-y-6 relative overflow-hidden">
        {/* Background gear animation */}
        <div className="absolute -right-8 -bottom-8 opacity-10 pointer-events-none animate-spin duration-10000 text-9xl">
          ⚙️
        </div>

        {/* Success Icon & Banner */}
        <div className="flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-green-900/60 border-2 border-green-500 flex items-center justify-center text-green-400 mb-2 shadow-lg">
            <CheckCircle2 size={36} />
          </div>
          <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
            Imperial Milestone Achieved
          </span>
          <h2 className="font-victorian text-2xl sm:text-3xl font-black text-[#ffd700]">
            STAGE {completedLevel} COMPLETED!
          </h2>
        </div>

        {/* Flavor text */}
        <div className="p-4 rounded bg-[#180f0a] border border-[#6d4018] shadow-inner">
          <p className="font-typewriter text-xs sm:text-sm text-[#f5e6c8] italic">
            "{TRANSITION_FLAVORS[completedLevel] || "The machine shudders and shifts to the next preposterous mechanism."}"
          </p>
        </div>

        {/* Up next preview */}
        <div className="p-3 bg-[#1e130c] border border-[#874b17] rounded-lg">
          <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">
            NEXT CONTRAPTION SUBSYSTEM:
          </span>
          <h3 className="font-victorian text-lg font-bold text-[#ffd700] mt-0.5">
            Stage {nextLevel}: {nextLevelTitle}
          </h3>
          <p className="text-xs font-mono-steampunk text-[#d4af37]">
            {nextLevelSubtitle}
          </p>
        </div>

        {/* Proceed Button */}
        <div>
          <button
            onClick={() => {
              sound.playClick();
              sound.playSteam(0.5, 0.7);
              onProceed();
            }}
            className="w-full sm:w-auto py-3 px-8 rounded-lg bg-gradient-to-r from-[#d4af37] via-[#f7d070] to-[#b87333] hover:brightness-110 text-black font-victorian font-black text-sm border-2 border-[#ffd700] shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 mx-auto cursor-pointer"
          >
            <span>PROCEED TO NEXT INCONVENIENCE</span>
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};
