import React, { useEffect, useRef } from 'react';
import { sound } from '../services/sound';
import { Play, BookOpen, Award, Volume2, VolumeX, Sparkles, Trophy } from 'lucide-react';

interface TitleScreenProps {
  onStart: () => void;
  onInstructions: () => void;
  onAchievements: () => void;
  onLeaderboard: () => void;
  isMuted: boolean;
  onToggleSound: () => void;
  bestTime: number | null;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  onStart,
  onInstructions,
  onAchievements,
  onLeaderboard,
  isMuted,
  onToggleSound,
  bestTime,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Background animated gears and steam particles
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let angle = 0;

    // Steam particles
    const particles = Array.from({ length: 25 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      radius: 4 + Math.random() * 12,
      speedY: 0.4 + Math.random() * 0.8,
      speedX: (Math.random() - 0.5) * 0.4,
      opacity: 0.1 + Math.random() * 0.3,
    }));

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      angle += 0.008;

      // Draw faint large background gears
      const drawGear = (x: number, y: number, r: number, teeth: number, speed: number, color: string) => {
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(angle * speed);

        ctx.beginPath();
        const toothAngle = (Math.PI * 2) / teeth;
        for (let i = 0; i < teeth; i++) {
          const a = i * toothAngle;
          ctx.lineTo(Math.cos(a) * (r + 10), Math.sin(a) * (r + 10));
          ctx.lineTo(Math.cos(a + toothAngle * 0.5) * r, Math.sin(a + toothAngle * 0.5) * r);
        }
        ctx.closePath();
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(0, 0, r * 0.5, 0, Math.PI * 2);
        ctx.strokeStyle = color;
        ctx.stroke();

        ctx.restore();
      };

      drawGear(80, 80, 90, 16, 1, 'rgba(212, 175, 55, 0.12)');
      drawGear(canvas.width - 90, 120, 110, 20, -0.8, 'rgba(184, 115, 51, 0.12)');
      drawGear(canvas.width / 2, canvas.height - 40, 130, 24, 0.5, 'rgba(212, 175, 55, 0.10)');

      // Draw floating steam particles
      particles.forEach(p => {
        p.y -= p.speedY;
        p.x += p.speedX;
        if (p.y < -20) {
          p.y = canvas.height + 20;
          p.x = Math.random() * canvas.width;
        }

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(200, 200, 210, ${p.opacity})`;
        ctx.fill();
      });

      animId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="relative w-full max-w-4xl mx-auto flex flex-col items-center justify-center p-4">
      {/* Background Animated Canvas */}
      <canvas
        ref={canvasRef}
        width={800}
        height={500}
        className="absolute inset-0 w-full h-full pointer-events-none rounded-2xl"
      />

      {/* Main Victorian Framing Box */}
      <div className="relative z-10 w-full bg-[#241710]/95 border-4 border-[#874b17] rounded-2xl p-6 sm:p-10 shadow-2xl text-center space-y-6">
        {/* Rivets */}
        <div className="absolute top-2 left-2 rivet" />
        <div className="absolute top-2 right-2 rivet" />
        <div className="absolute bottom-2 left-2 rivet" />
        <div className="absolute bottom-2 right-2 rivet" />

        {/* Top Victorian Kicker */}
        <div className="flex items-center justify-center gap-2 text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase">
          <span>⚙️ THE LONDON EXHIBITION OF 1889 ⚙️</span>
        </div>

        {/* Giant Steampunk Title */}
        <div className="space-y-1">
          <h1 className="font-victorian text-4xl sm:text-6xl font-black text-[#ffd700] tracking-wider drop-shadow-[0_5px_5px_rgba(0,0,0,0.8)]">
            STEAM<span className="text-[#e69138]">.exe</span>
          </h1>
          <h2 className="font-victorian text-lg sm:text-2xl font-bold text-[#f5e6c8] tracking-widest">
            THE WORLD'S MOST INCONVENIENT MACHINE
          </h2>
          <p className="font-typewriter text-xs sm:text-sm text-[#d4af37] max-w-lg mx-auto italic mt-2">
            "A comedy puzzle of thermodynamic panic, inverted mechanics, and royal bureaucracy
            — in pursuit of ONE SOLITARY CUP OF TEA."
          </p>
        </div>

        {/* Central Character & Contraption Illustration */}
        <div className="p-4 rounded-xl bg-[#190f0a] border-2 border-[#6d4018] max-w-md mx-auto shadow-inner flex items-center justify-around gap-4">
          <div className="flex flex-col items-center">
            <span className="text-4xl animate-bounce">🧐</span>
            <span className="text-[11px] font-victorian font-bold text-[#ffd700] mt-1">
              Prof. Cogsworth
            </span>
            <span className="text-[9px] font-mono-steampunk text-[#a8a9ad]">
              (Deluded Inventor)
            </span>
          </div>

          <div className="text-2xl text-[#b87333] font-bold">
            ⚔️
          </div>

          <div className="flex flex-col items-center">
            <span className="text-4xl">🤖</span>
            <span className="text-[11px] font-victorian font-bold text-[#ffd700] mt-1">
              Sir Clankington
            </span>
            <span className="text-[9px] font-mono-steampunk text-[#a8a9ad]">
              (Sarcastic Automaton)
            </span>
          </div>
        </div>

        {/* Best Record display */}
        {bestTime !== null && (
          <div className="text-xs font-mono-steampunk text-[#22c55e] flex items-center justify-center gap-1.5">
            <Sparkles size={14} />
            <span>FASTEST REGISTERED BREW: {(bestTime / 60).toFixed(0)}m {(bestTime % 60).toFixed(0)}s</span>
          </div>
        )}

        {/* Main Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-2">
          <button
            onClick={() => {
              sound.playClick();
              sound.playSteam(0.8, 0.6);
              onStart();
            }}
            className="w-full sm:w-auto py-3.5 px-8 rounded-lg bg-gradient-to-r from-[#d4af37] via-[#f7d070] to-[#b87333] hover:brightness-110 text-black font-victorian font-black text-sm sm:text-base border-2 border-[#ffd700] shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play size={20} className="fill-black" />
            <span>OPERATE MACHINE (START)</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onInstructions();
            }}
            className="w-full sm:w-auto py-3 px-6 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#f5e6c8] font-victorian font-bold text-xs sm:text-sm border-2 border-[#874b17] hover:border-[#ffd700] shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <BookOpen size={18} />
            <span>PATENT MANUAL</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onAchievements();
            }}
            className="w-full sm:w-auto py-3 px-5 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#ffd700] font-victorian font-bold text-xs sm:text-sm border-2 border-[#874b17] hover:border-[#ffd700] shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Award size={18} />
            <span>MEDALS</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onLeaderboard();
            }}
            className="w-full sm:w-auto py-3 px-5 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#ffd700] font-victorian font-bold text-xs sm:text-sm border-2 border-[#874b17] hover:border-[#ffd700] shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Trophy size={18} />
            <span>LEADERBOARD</span>
          </button>
        </div>

        {/* Audio Toggle Footer */}
        <div className="pt-2 flex items-center justify-between text-xs font-mono-steampunk text-[#a8a9ad]">
          <span>ROYAL PATENT OFFICE #882</span>
          <button
            onClick={onToggleSound}
            className="hover:text-white flex items-center gap-1 cursor-pointer"
          >
            {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            <span>AUDIO: {isMuted ? 'MUTED' : 'ENGAGED'}</span>
          </button>
          <span>100% INDIE COMEDY</span>
        </div>
      </div>
    </div>
  );
};
