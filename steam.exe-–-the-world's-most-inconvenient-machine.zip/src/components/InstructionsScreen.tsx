import React from 'react';
import { sound } from '../services/sound';
import { ArrowLeft, Play, ShieldAlert, Cpu, FileCheck } from 'lucide-react';

interface InstructionsScreenProps {
  onBack: () => void;
  onStart: () => void;
}

export const InstructionsScreen: React.FC<InstructionsScreenProps> = ({ onBack, onStart }) => {
  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Victorian Parchment Document */}
      <div className="bg-[#fbf4e2] text-[#2c1a0e] rounded-xl border-4 border-[#874b17] shadow-2xl p-6 sm:p-8 relative font-typewriter">
        {/* Header */}
        <div className="border-b-2 border-[#874b17] pb-4 mb-6 text-center">
          <span className="text-xs font-mono-steampunk text-[#874b17] font-bold tracking-widest uppercase">
            Official Imperial Operational Compendium
          </span>
          <h2 className="font-victorian text-2xl sm:text-3xl font-bold text-[#4a2810] mt-1">
            HOW TO OPERATE THE WORLD'S MOST INCONVENIENT MACHINE
          </h2>
          <p className="text-xs text-[#6e4624] italic mt-1">
            (Read carefully; Her Majesty's Government accepts zero liability for steam-induced baldness)
          </p>
        </div>

        {/* Section 1: The Ultimate Mission */}
        <div className="space-y-4 text-xs sm:text-sm leading-relaxed text-[#3a200d]">
          <div className="p-3.5 bg-[#f4e8ce] rounded border border-[#d6c19a]">
            <h3 className="font-victorian font-bold text-sm text-[#4a2810] flex items-center gap-2 mb-1">
              <span>🎯</span> THE OBJECTIVE: ONE CUP OF TEA
            </h3>
            <p>
              Professor Cogsworth has devoted 27 years of his life and £4,000,000 to construct
              a colossal 10-ton steam contraption. Your task is simple: navigate all 5 stages of
              calamitous mechanical inconvenience to brew a single cup of tea.
            </p>
          </div>

          {/* Section 2: The 5 Stages */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3 bg-[#f8efe0] rounded border border-[#dfceb0]">
              <h4 className="font-victorian font-bold text-xs text-[#874b17]">
                STAGE I: WAKE THE MACHINE
              </h4>
              <p className="text-xs text-[#52331c] mt-1">
                Five levers await. Labels are maliciously deceptive. Trust no official markings.
                Think like an eccentric Victorian inventor.
              </p>
            </div>

            <div className="p-3 bg-[#f8efe0] rounded border border-[#dfceb0]">
              <h4 className="font-victorian font-bold text-xs text-[#874b17]">
                STAGE II: BOILER PANIC
              </h4>
              <p className="text-xs text-[#52331c] mt-1">
                Stoke the furnace and vent the safety valve to keep pressure in the highlighted safe zone for 20 cumulative seconds.
                The safe zone shifts periodically!
              </p>
            </div>

            <div className="p-3 bg-[#f8efe0] rounded border border-[#dfceb0]">
              <h4 className="font-victorian font-bold text-xs text-[#874b17]">
                STAGE III: THE GEAR DISASTER
              </h4>
              <p className="text-xs text-[#52331c] mt-1">
                Align all 4 gears with their target notches. Every 10 seconds, rotation controls invert due to Reverse Torque Syndrome.
              </p>
            </div>

            <div className="p-3 bg-[#f8efe0] rounded border border-[#dfceb0]">
              <h4 className="font-victorian font-bold text-xs text-[#874b17]">
                STAGE IV: DEPT. OF PERMISSIONS
              </h4>
              <p className="text-xs text-[#52331c] mt-1">
                Submit Form 42-B to Her Majesty's clerk. Consult the auditor's scribbled notes to avoid immediate bureaucratic rejection!
              </p>
            </div>
          </div>

          {/* Section 3: Intentionally Bad Mechanics Guide */}
          <div className="p-3.5 bg-[#edd7ae] rounded border border-[#874b17] space-y-2">
            <h3 className="font-victorian font-bold text-sm text-[#4a2810] flex items-center gap-2">
              <ShieldAlert size={16} /> DELIBERATE INCONVENIENCES YOU MUST OVERCOME
            </h3>
            <ul className="list-disc list-inside space-y-1 text-xs text-[#4a2810]">
              <li><strong>Erratic Productivity Gauge:</strong> The progress bar will frequently move backwards. Ignore its pessimism; your real stage is tracked at the top.</li>
              <li><strong>Sir Clankington:</strong> The robot assistant will insult your lineage and offer intentionally terrible advice. Click him if you enjoy verbal abuse.</li>
              <li><strong>Boiler Explosions:</strong> Reaching 100 PSI will detonate the machine. You have 3 fuses before a catastrophic system reset.</li>
            </ul>
          </div>
        </div>

        {/* Buttons */}
        <div className="border-t-2 border-[#874b17] pt-4 mt-6 flex flex-wrap items-center justify-between gap-4">
          <button
            onClick={() => {
              sound.playClick();
              onBack();
            }}
            className="py-2.5 px-4 rounded bg-[#ded0b6] hover:bg-[#c9b99e] text-[#4a2810] font-victorian font-bold text-xs border border-[#874b17] transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowLeft size={16} />
            <span>RETURN TO TITLE</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              sound.playSteam(0.8, 0.6);
              onStart();
            }}
            className="py-2.5 px-6 rounded-lg bg-gradient-to-r from-[#874b17] to-[#4f270a] hover:from-[#a05a1e] text-[#ffd700] font-victorian font-bold text-xs sm:text-sm border-2 border-[#d4af37] shadow-lg hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
          >
            <Play size={16} className="fill-[#ffd700]" />
            <span>COMMENCE OPERATION</span>
          </button>
        </div>
      </div>
    </div>
  );
};
