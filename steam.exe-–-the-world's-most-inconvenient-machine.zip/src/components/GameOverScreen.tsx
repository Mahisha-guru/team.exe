import React, { useEffect } from 'react';
import { sound } from '../services/sound';
import { RotateCcw, Home, Skull, Flame } from 'lucide-react';

interface GameOverScreenProps {
  level: number;
  reason: string;
  onRetryLevel: () => void;
  onRestartGame: () => void;
}

export const GameOverScreen: React.FC<GameOverScreenProps> = ({
  level,
  reason,
  onRetryLevel,
  onRestartGame,
}) => {
  useEffect(() => {
    sound.playExplosion();
  }, []);

  return (
    <div className="w-full max-w-2xl mx-auto my-auto p-4 animate-shake-violent">
      <div className="bg-[#1f100a] border-4 border-[#b22222] rounded-xl p-6 sm:p-8 shadow-2xl text-center space-y-6 relative overflow-hidden">
        {/* Glow red alert aura */}
        <div className="absolute inset-0 bg-red-950/20 pointer-events-none" />

        <div className="flex flex-col items-center">
          <div className="w-16 h-16 rounded-full bg-red-950/80 border-2 border-[#b22222] flex items-center justify-center text-red-500 mb-2 shadow-2xl animate-pulse">
            <Flame size={36} />
          </div>
          <span className="text-xs font-mono-steampunk text-[#b22222] tracking-widest uppercase font-bold">
            Catastrophic Steam Failure
          </span>
          <h2 className="font-victorian text-3xl font-black text-[#ffd700]">
            TOTAL DISASSEMBLY OCCURRED
          </h2>
        </div>

        {/* Reason */}
        <div className="p-4 rounded bg-[#150a06] border border-[#6b1e1e] shadow-inner text-left space-y-1">
          <span className="text-xs font-mono-steampunk text-[#d4af37] font-bold block">
            INSPECTOR CORONER REPORT:
          </span>
          <p className="font-typewriter text-xs sm:text-sm text-[#f5e6c8]">
            "{reason || "The machine exceeded maximum permissible pressure. Shrapnel landed across three postal districts."}"
          </p>
        </div>

        {/* Sir Clankington Eulogy */}
        <div className="p-3 bg-[#241710] border border-[#874b17] rounded-lg text-center">
          <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">
            SIR CLANKINGTON'S FINAL WORDS ON THE MATTER:
          </span>
          <p className="font-typewriter text-xs text-[#ffd700] italic mt-1">
            "Fascinating. You have managed to convert £4,000,000 of brass into high-velocity scrap metal. Shall I inform your next of kin, or shall we pretend this was intentional?"
          </p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            onClick={() => {
              sound.playClick();
              onRetryLevel();
            }}
            className="w-full sm:w-auto py-3 px-6 rounded-lg bg-gradient-to-r from-[#d4af37] to-[#b87333] hover:brightness-110 text-black font-victorian font-black text-sm border-2 border-[#ffd700] shadow-xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw size={18} />
            <span>PATCH BOILER & RETRY STAGE {level}</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onRestartGame();
            }}
            className="w-full sm:w-auto py-2.5 px-5 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#f5e6c8] font-victorian font-bold text-xs border border-[#874b17] hover:border-[#ffd700] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home size={16} />
            <span>RESTART FROM STAGE 1</span>
          </button>
        </div>
      </div>
    </div>
  );
};
