import React, { useState, useEffect } from 'react';
import { sound } from '../services/sound';
import { X, Trophy, LogIn, LogOut, Clock, Flame, User } from 'lucide-react';
import { CloudStorageService, LeaderboardEntry } from '../services/cloudStorage';
import { auth, signInWithGoogle, logOut } from '../services/firebase';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

interface LeaderboardModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ isOpen, onClose }) => {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [user, setUser] = useState<FirebaseUser | null>(auth.currentUser);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
    });

    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (!isOpen) return;
    setIsLoading(true);

    const unsubscribe = CloudStorageService.subscribeToLeaderboard((data) => {
      setEntries(data);
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [isOpen]);

  if (!isOpen) return null;

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${mins}m ${rem}s`;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#241710] border-4 border-[#874b17] rounded-xl p-6 max-w-xl w-full shadow-2xl relative max-h-[90vh] flex flex-col">
        <div className="absolute top-2 left-2 rivet" />
        <div className="absolute top-2 right-2 rivet" />
        <div className="absolute bottom-2 left-2 rivet" />
        <div className="absolute bottom-2 right-2 rivet" />

        {/* Header */}
        <div className="flex items-center justify-between border-b-2 border-[#874b17] pb-3 mb-4">
          <div className="flex items-center gap-2">
            <Trophy className="text-[#ffd700]" size={26} />
            <div>
              <h3 className="font-victorian text-lg font-bold text-[#ffd700]">
                IMPERIAL TELEGRAPH LEADERBOARD
              </h3>
              <p className="text-[10px] font-mono-steampunk text-[#a8a9ad]">
                Fastest Certified Tea Extractions Recorded on Firestore
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="p-1 rounded text-[#a8a9ad] hover:text-white hover:bg-[#3d2516] transition-all cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>

        {/* User Account / Google Sign-in bar */}
        <div className="mb-4 p-2.5 rounded bg-[#180f0a] border border-[#6d4018] flex items-center justify-between gap-2 text-xs font-mono-steampunk">
          <div className="flex items-center gap-2 truncate">
            <User size={16} className="text-[#d4af37] flex-shrink-0" />
            {user ? (
              <span className="truncate text-[#f5e6c8]">
                Inventor: <strong className="text-[#ffd700]">{user.displayName || user.email}</strong>
              </span>
            ) : (
              <span className="text-[#a8a9ad]">
                Guest Operator (Sign in to record your times to Firestore)
              </span>
            )}
          </div>

          {user ? (
            <button
              onClick={async () => {
                sound.playClick();
                await logOut();
              }}
              className="px-2.5 py-1 rounded bg-[#382215] hover:bg-[#52331f] text-xs text-[#a8a9ad] hover:text-white border border-[#874b17] flex items-center gap-1 cursor-pointer flex-shrink-0"
            >
              <LogOut size={12} />
              <span>Sign Out</span>
            </button>
          ) : (
            <button
              onClick={async () => {
                sound.playClick();
                await signInWithGoogle();
              }}
              className="px-3 py-1 rounded bg-brass-plate text-black font-victorian font-bold text-xs border border-[#ffd700] hover:brightness-110 flex items-center gap-1 cursor-pointer shadow flex-shrink-0"
            >
              <LogIn size={12} />
              <span>Google Sign-In</span>
            </button>
          )}
        </div>

        {/* Leaderboard Table */}
        <div className="overflow-y-auto space-y-2 pr-1 flex-1">
          {isLoading ? (
            <div className="text-center py-8 text-xs font-mono-steampunk text-[#d4af37] animate-pulse">
              ⚙️ Connecting via transatlantic pneumatic tube...
            </div>
          ) : entries.length === 0 ? (
            <div className="text-center py-8 text-xs font-typewriter text-[#a8a9ad] italic">
              No brave inventors have successfully registered a cup of tea yet. Be the first!
            </div>
          ) : (
            entries.map((entry, idx) => (
              <div
                key={entry.id || idx}
                className={`p-2.5 rounded-lg border flex items-center justify-between gap-3 text-xs font-mono-steampunk ${
                  idx === 0
                    ? 'bg-[#3b271a] border-[#ffd700] shadow-md'
                    : 'bg-[#1b110a] border-[#442510]'
                }`}
              >
                {/* Rank & Name */}
                <div className="flex items-center gap-2.5 min-w-0">
                  <span
                    className={`w-6 h-6 rounded-full flex items-center justify-center font-bold font-victorian text-[11px] ${
                      idx === 0
                        ? 'bg-[#ffd700] text-black'
                        : idx === 1
                        ? 'bg-[#a8a9ad] text-black'
                        : idx === 2
                        ? 'bg-[#cd7f32] text-black'
                        : 'bg-[#29170e] text-[#a8a9ad] border border-[#553b27]'
                    }`}
                  >
                    {idx + 1}
                  </span>
                  <div className="truncate">
                    <span className="font-bold text-[#f5e6c8] block truncate">
                      {entry.inventorName}
                    </span>
                    <span className="text-[10px] text-[#a8a9ad]">
                      {new Date(entry.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* Stats */}
                <div className="flex items-center gap-4 flex-shrink-0">
                  <div className="flex items-center gap-1 text-[#ffd700] font-bold" title="Time elapsed">
                    <Clock size={13} />
                    <span>{formatTime(entry.timeElapsed)}</span>
                  </div>
                  <div className="flex items-center gap-1 text-[#e69138]" title="Boiler explosions">
                    <Flame size={13} />
                    <span>{entry.boilerBreaches}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-[#874b17] mt-3 flex items-center justify-between">
          <span className="text-[10px] font-mono-steampunk text-[#874b17]">
            Connected to Cloud Firestore
          </span>
          <button
            onClick={() => {
              sound.playClick();
              onClose();
            }}
            className="py-1.5 px-4 rounded bg-[#382215] hover:bg-[#52331f] text-[#f5e6c8] font-victorian font-bold text-xs border border-[#874b17] cursor-pointer"
          >
            CLOSE REGISTRY
          </button>
        </div>
      </div>
    </div>
  );
};
