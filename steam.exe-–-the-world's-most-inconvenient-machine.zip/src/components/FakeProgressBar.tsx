import React, { useState, useEffect } from 'react';

interface FakeProgressBarProps {
  realLevel: number; // 1 to 5
}

export const FakeProgressBar: React.FC<FakeProgressBarProps> = ({ realLevel }) => {
  const [fakePercent, setFakePercent] = useState<number>(42);
  const [glitchText, setGlitchText] = useState<string>('EFFICIENCY NOMINAL');

  // Intentionally erratic backwards-and-forwards movement
  useEffect(() => {
    const interval = setInterval(() => {
      // Intentionally erratic delta: mostly fluctuates or drifts backwards!
      setFakePercent(prev => {
        const jump = (Math.random() - 0.55) * 14;
        let next = prev + jump;
        if (next > 96) next = 12; // hilarious sudden reset
        if (next < -15) next = 35;
        return Math.round(next);
      });

      const glitches = [
        'CALIBRATING TO LUNAR PHASE',
        'EFFICIENCY DILUTED BY 14%',
        'REVERSING PROGRESS FOR SAFETY',
        'PRODUCTIVITY ANOMALY DETECTED',
        'SUBTRACTING OVERCONFIDENCE',
        'STEAM PRESSURE INFLATION',
        'RETARDING COGS BY ORDER OF GUILD',
      ];
      setGlitchText(glitches[Math.floor(Math.random() * glitches.length)]);
    }, 2800);

    return () => clearInterval(interval);
  }, []);

  const romanNumerals = ['I', 'II', 'III', 'IV', 'V'];

  return (
    <div className="w-full bg-[#1e130c] border border-[#874b17] rounded p-2.5 shadow-inner">
      {/* Top row: Real milestone vs Fake gauge title */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs mb-1.5">
        <div className="flex items-center gap-1.5 font-victorian font-bold text-[#d4af37]">
          <span>PATENT STAGE:</span>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map(step => (
              <span
                key={step}
                className={`px-1.5 py-0.5 rounded text-[11px] font-mono-steampunk border ${
                  step === realLevel
                    ? 'bg-[#d4af37] text-[#1c120c] font-black border-[#ffd700] shadow'
                    : step < realLevel
                    ? 'bg-[#4f270a] text-[#874b17] border-[#4f270a]'
                    : 'bg-[#150d08] text-[#553b27] border-[#382215]'
                }`}
              >
                {romanNumerals[step - 1]}
              </span>
            ))}
          </div>
        </div>

        <div className="text-[11px] font-mono-steampunk text-[#a8a9ad] italic">
          [Actual Goal: 1 Cup of Tea]
        </div>
      </div>

      {/* The Deliberately Terrible Erratic Bar */}
      <div className="space-y-1">
        <div className="flex items-center justify-between text-[11px] font-mono-steampunk text-[#e69138]">
          <span className="truncate max-w-[220px]">
            ERRATIC PRODUCTIVITY METER: {glitchText}
          </span>
          <span className="font-bold text-[#ffd700]">
            {fakePercent}% (±{Math.abs(fakePercent % 19)}%)
          </span>
        </div>

        <div className="h-3 w-full bg-[#120a06] rounded-xs border border-[#52331c] overflow-hidden relative">
          {/* Backwards striped fill */}
          <div
            className="h-full bg-gradient-to-r from-[#b22222] via-[#d4af37] to-[#b87333] transition-all duration-700 ease-out"
            style={{ width: `${Math.max(5, Math.min(100, fakePercent + 20))}%` }}
          />
          <div className="absolute inset-0 flex items-center justify-center text-[9px] font-bold text-white tracking-widest drop-shadow opacity-75">
            CALIBRATED BY DRUNK CARTOGRAPHER
          </div>
        </div>
      </div>
    </div>
  );
};
