import React, { useEffect, useRef, useState } from 'react';
import { sound } from '../services/sound';
import { Award, RotateCcw, Sparkles, Star, Trophy, Send, LogIn, CheckCircle } from 'lucide-react';
import { GameStats, Achievement } from '../types/game';
import { auth, signInWithGoogle } from '../services/firebase';
import { CloudStorageService } from '../services/cloudStorage';
import { onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';

interface VictoryScreenProps {
  stats: GameStats;
  achievements: Achievement[];
  onRestart: () => void;
  onOpenLeaderboard: () => void;
}

export const VictoryScreen: React.FC<VictoryScreenProps> = ({
  stats,
  achievements,
  onRestart,
  onOpenLeaderboard,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [user, setUser] = useState<FirebaseUser | null>(auth.currentUser);
  const [inventorName, setInventorName] = useState<string>('Prof. Cogsworth');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [submittedRunId, setSubmittedRunId] = useState<string | null>(null);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      if (u?.displayName) {
        setInventorName(u.displayName);
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    sound.playVictory();
  }, []);

  // Steampunk celebration particles (golden cogs, brass confetti, steam clouds)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const items = Array.from({ length: 40 }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * -200,
      size: 5 + Math.random() * 8,
      speedY: 1.5 + Math.random() * 2.5,
      speedX: (Math.random() - 0.5) * 1.5,
      rotation: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.1,
      color: ['#ffd700', '#d4af37', '#b87333', '#e69138', '#ffffff'][Math.floor(Math.random() * 5)],
      isCog: Math.random() > 0.5,
    }));

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      items.forEach(item => {
        item.y += item.speedY;
        item.x += item.speedX;
        item.rotation += item.rotSpeed;

        if (item.y > canvas.height + 20) {
          item.y = -20;
          item.x = Math.random() * canvas.width;
        }

        ctx.save();
        ctx.translate(item.x, item.y);
        ctx.rotate(item.rotation);

        if (item.isCog) {
          // Tiny falling gear
          ctx.beginPath();
          ctx.arc(0, 0, item.size, 0, Math.PI * 2);
          ctx.fillStyle = item.color;
          ctx.fill();
        } else {
          // Falling tea leaf / spark
          ctx.fillStyle = item.color;
          ctx.fillRect(-item.size / 2, -item.size / 2, item.size, item.size * 1.5);
        }

        ctx.restore();
      });

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, []);

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = Math.floor(secs % 60);
    return `${mins}m ${rem}s`;
  };

  return (
    <div className="relative w-full max-w-3xl mx-auto my-auto p-4 animate-in zoom-in-95 duration-500">
      <canvas
        ref={canvasRef}
        width={700}
        height={650}
        className="absolute inset-0 w-full h-full pointer-events-none rounded-2xl"
      />

      <div className="relative z-10 bg-[#241710] border-4 border-[#ffd700] rounded-2xl p-6 sm:p-10 shadow-2xl text-center space-y-6">
        {/* Rivets */}
        <div className="absolute top-2 left-2 rivet" />
        <div className="absolute top-2 right-2 rivet" />
        <div className="absolute bottom-2 left-2 rivet" />
        <div className="absolute bottom-2 right-2 rivet" />

        {/* Hero Tiny Teacup presentation */}
        <div className="flex flex-col items-center">
          <div className="relative w-28 h-28 rounded-full bg-brass-plate border-4 border-[#ffd700] flex items-center justify-center shadow-2xl mb-3 glow-amber">
            {/* The single tiny teacup! */}
            <span className="text-4xl animate-bounce">☕</span>
            {/* Rising steam vapor */}
            <span className="absolute -top-3 text-lg opacity-80 animate-pulse">
              💨
            </span>
          </div>

          <span className="text-xs font-mono-steampunk text-[#d4af37] tracking-widest uppercase font-bold">
            The London Exhibition of 1889
          </span>
          <h2 className="font-victorian text-3xl sm:text-5xl font-black text-[#ffd700] tracking-wider drop-shadow">
            CONGRATULATIONS!
          </h2>
        </div>

        {/* The Exact Punchline */}
        <div className="p-4 rounded-xl bg-[#1a0f0a] border-2 border-[#874b17] shadow-inner space-y-2">
          <p className="font-victorian text-sm sm:text-base text-[#f5e6c8]">
            "After 27 years, 14 explosions, and £4 million in municipal damages..."
          </p>
          <p className="font-victorian text-lg sm:text-xl font-bold text-[#ffd700]">
            YOU HAVE SUCCESSFULLY MADE ONE CUP OF TEA.
          </p>
        </div>

        {/* Final Official Score Box: 1/10 */}
        <div className="p-4 rounded-xl bg-[#2e150b] border-2 border-[#b22222] flex flex-col items-center justify-center space-y-1">
          <div className="flex items-center gap-1 text-[#ffd700]">
            <Star size={24} className="fill-[#ffd700]" />
            <span className="font-victorian text-2xl sm:text-3xl font-black">
              FINAL SCORE: 1 / 10
            </span>
          </div>
          <p className="font-typewriter text-xs sm:text-sm text-[#e69138] italic">
            "Critic Review: Tea was slightly cold. Milk curdled. But Professor Cogsworth wept with pure unadulterated joy."
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
          <div className="p-2.5 bg-[#190f0a] border border-[#6d4018] rounded">
            <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">TOTAL TIME</span>
            <span className="font-mono-steampunk text-sm font-bold text-[#ffd700]">
              {formatTime(stats.timeElapsed)}
            </span>
          </div>
          <div className="p-2.5 bg-[#190f0a] border border-[#6d4018] rounded">
            <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">BOILER BREACHES</span>
            <span className="font-mono-steampunk text-sm font-bold text-[#e69138]">
              {stats.boilerBreaches}
            </span>
          </div>
          <div className="p-2.5 bg-[#190f0a] border border-[#6d4018] rounded">
            <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">STEAM VENTED</span>
            <span className="font-mono-steampunk text-sm font-bold text-[#ffd700]">
              ~{Math.max(12, Math.round(stats.steamVentedLiters))} Liters
            </span>
          </div>
          <div className="p-2.5 bg-[#190f0a] border border-[#6d4018] rounded">
            <span className="text-[10px] font-mono-steampunk text-[#a8a9ad] block">INSULTS SUFFERED</span>
            <span className="font-mono-steampunk text-sm font-bold text-[#ffd700]">
              {stats.insultsEndured}
            </span>
          </div>
        </div>

        {/* Unlocked Medals Row */}
        <div className="p-3 bg-[#1c120c] rounded-lg border border-[#874b17]">
          <span className="text-xs font-victorian font-bold text-[#ffd700] block mb-2">
            IMPERIAL MEDALS EARNED
          </span>
          <div className="flex flex-wrap items-center justify-center gap-2">
            {achievements.filter(a => a.unlocked).map(a => (
              <span
                key={a.id}
                className="px-2 py-1 bg-[#332014] border border-[#d4af37] rounded text-xs font-mono-steampunk text-[#ffd700] flex items-center gap-1"
                title={a.description}
              >
                <span>{a.icon}</span>
                <span>{a.title}</span>
              </span>
            ))}
          </div>
        </div>

        {/* Imperial Leaderboard Telegraph Submission Card */}
        <div className="p-4 bg-[#1e130c] rounded-xl border-2 border-[#874b17] space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-victorian text-xs font-bold text-[#ffd700] flex items-center gap-1.5">
              <Trophy size={16} className="text-[#ffd700]" />
              HER MAJESTY'S GLOBAL TELEGRAPH REGISTRY
            </span>
            <button
              onClick={onOpenLeaderboard}
              className="text-[11px] font-mono-steampunk text-[#d4af37] underline hover:text-white cursor-pointer"
            >
              View Leaderboard
            </button>
          </div>

          {submittedRunId ? (
            <div className="p-2.5 bg-green-950/60 border border-green-600 rounded text-green-300 text-xs font-mono-steampunk flex items-center justify-center gap-2">
              <CheckCircle size={16} />
              <span>RECORDED ON FIRESTORE! Your speedrun is enshrined in the archives.</span>
            </div>
          ) : user ? (
            <div className="flex flex-col sm:flex-row items-center gap-2">
              <input
                type="text"
                value={inventorName}
                onChange={(e) => setInventorName(e.target.value)}
                placeholder="Inventor Alias"
                maxLength={32}
                className="w-full sm:flex-1 bg-[#120a06] border border-[#874b17] rounded px-3 py-1.5 text-xs text-[#f5e6c8] font-mono-steampunk focus:outline-none focus:border-[#ffd700]"
              />
              <button
                disabled={isSubmitting}
                onClick={async () => {
                  setIsSubmitting(true);
                  sound.playClick();
                  const docId = await CloudStorageService.submitScore(stats, inventorName);
                  setIsSubmitting(false);
                  if (docId) {
                    setSubmittedRunId(docId);
                    sound.playStamp(true);
                  }
                }}
                className="w-full sm:w-auto py-1.5 px-4 rounded bg-brass-plate text-black font-victorian font-bold text-xs border border-[#ffd700] hover:brightness-110 flex items-center justify-center gap-1.5 cursor-pointer shadow"
              >
                <Send size={13} />
                <span>{isSubmitting ? 'TRANSMITTING...' : 'RECORD ON LEADERBOARD'}</span>
              </button>
            </div>
          ) : (
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 p-2 bg-[#120a06] rounded border border-[#6d4018]">
              <span className="text-xs font-mono-steampunk text-[#a8a9ad]">
                Sign in with Google to post your {formatTime(stats.timeElapsed)} record to the global leaderboard:
              </span>
              <button
                onClick={async () => {
                  sound.playClick();
                  await signInWithGoogle();
                }}
                className="py-1 px-3 rounded bg-brass-plate text-black font-victorian font-bold text-xs border border-[#ffd700] hover:brightness-110 flex items-center gap-1.5 cursor-pointer flex-shrink-0"
              >
                <LogIn size={13} />
                <span>Google Sign-In</span>
              </button>
            </div>
          )}
        </div>

        {/* Sir Clankington Post-Game Roast */}
        <div className="text-center font-typewriter text-xs text-[#a8a9ad] italic">
          Sir Clankington notes: "A triumph of stubbornness over common sense. Shall we boil another cup?"
        </div>

        {/* Action Buttons Row */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => {
              sound.playClick();
              sound.playSteam(0.8, 0.6);
              onRestart();
            }}
            className="w-full sm:w-auto py-3 px-6 rounded-lg bg-gradient-to-r from-[#d4af37] via-[#f7d070] to-[#b87333] hover:brightness-110 text-black font-victorian font-black text-sm border-2 border-[#ffd700] shadow-2xl hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw size={18} />
            <span>BREW ANOTHER CUP (MAY GOD HAVE MERCY)</span>
          </button>

          <button
            onClick={() => {
              sound.playClick();
              onOpenLeaderboard();
            }}
            className="w-full sm:w-auto py-3 px-5 rounded-lg bg-[#382215] hover:bg-[#52331f] text-[#ffd700] font-victorian font-bold text-xs border-2 border-[#874b17] hover:border-[#ffd700] shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Trophy size={18} />
            <span>GLOBAL LEADERBOARD</span>
          </button>
        </div>
      </div>
    </div>
  );
};
