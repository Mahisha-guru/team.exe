import React, { useState, useEffect, useRef } from 'react';
import { GameScreen, LevelId, LevelConfig, GameStats, Achievement } from './types/game';
import { sound } from './services/sound';
import { StorageService } from './services/storage';

import { HeaderHUD } from './components/HeaderHUD';
import { TitleScreen } from './components/TitleScreen';
import { InstructionsScreen } from './components/InstructionsScreen';
import { PauseMenu } from './components/PauseMenu';
import { GameOverScreen } from './components/GameOverScreen';
import { VictoryScreen } from './components/VictoryScreen';
import { LevelTransitionScreen } from './components/LevelTransitionScreen';
import { AchievementsModal } from './components/AchievementsModal';
import { LeaderboardModal } from './components/LeaderboardModal';
import { testConnection } from './services/firebase';

import { Level1WakeMachine } from './components/levels/Level1WakeMachine';
import { Level2BoilerPanic } from './components/levels/Level2BoilerPanic';
import { Level3GearDisaster } from './components/levels/Level3GearDisaster';
import { Level4DepartmentOfPermissions } from './components/levels/Level4DepartmentOfPermissions';
import { Level5FinalCupOfTea } from './components/levels/Level5FinalCupOfTea';

const LEVEL_CONFIGS: Record<LevelId, LevelConfig> = {
  1: {
    id: 1,
    title: "WAKE THE MACHINE",
    subtitle: "The Five Levers of Uncertainty",
    objective: "Identify and pull the solitary ignition lever.",
    inventorNote: "Never pull what appears to be the start.",
  },
  2: {
    id: 2,
    title: "BOILER PANIC",
    subtitle: "Thermodynamic Incompetence",
    objective: "Hold steam in the shifting safe zone for 20 cumulative seconds.",
    inventorNote: "Pressure over 100 PSI will vaporize the workshop.",
  },
  3: {
    id: 3,
    title: "THE GEAR DISASTER",
    subtitle: "Babbage's Torque Nightmare",
    objective: "Align all 4 gears with target notches despite inverted controls.",
    inventorNote: "Controls invert every 10 seconds. Adapt or perish.",
  },
  4: {
    id: 4,
    title: "DEPT. OF PERMISSIONS",
    subtitle: "Form 42-B Regulation",
    objective: "Obtain official bureaucratic authorization to agitate water.",
    inventorNote: "Water demands written consent; kettles require patriotism.",
  },
  5: {
    id: 5,
    title: "THE FINAL CUP OF TEA",
    subtitle: "The Master Infusion Plunger",
    objective: "Complete the 5-step brewing protocol to yield 1 cup of tea.",
    inventorNote: "All safety interlocks converge. Stand back.",
  },
};

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('TITLE');
  const [currentLevel, setCurrentLevel] = useState<LevelId>(1);
  const [attempts, setAttempts] = useState<number>(3);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(sound.getMuted());
  const [showAchievements, setShowAchievements] = useState<boolean>(false);
  const [showLeaderboard, setShowLeaderboard] = useState<boolean>(false);
  const [screenShake, setScreenShake] = useState<'none' | 'mild' | 'violent'>('none');
  const [gameOverReason, setGameOverReason] = useState<string>('');
  const [achievementToast, setAchievementToast] = useState<Achievement | null>(null);

  // Test Firestore connection on boot
  useEffect(() => {
    testConnection();
  }, []);

  // Stats
  const [stats, setStats] = useState<GameStats>({
    timeElapsed: 0,
    boilerBreaches: 0,
    attemptsLost: 0,
    steamVentedLiters: 15,
    permitsSubmitted: 0,
    insultsEndured: 3,
  });

  const [achievements, setAchievements] = useState<Achievement[]>(StorageService.getAchievements());
  const [bestTime, setBestTime] = useState<number | null>(StorageService.getBestTime());

  // Global Timer (ticks while PLAYING and not paused)
  useEffect(() => {
    if (currentScreen !== 'PLAYING' || isPaused) return;

    const timer = setInterval(() => {
      setStats(prev => ({
        ...prev,
        timeElapsed: prev.timeElapsed + 1,
        steamVentedLiters: prev.steamVentedLiters + 0.4,
      }));
    }, 1000);

    return () => clearInterval(timer);
  }, [currentScreen, isPaused]);

  // Helper: Trigger screen shake
  const triggerShake = (intensity: 'mild' | 'violent') => {
    setScreenShake(intensity);
    setTimeout(() => {
      setScreenShake('none');
    }, intensity === 'violent' ? 600 : 350);
  };

  // Helper: Unlock achievement with toast
  const awardAchievement = (id: string) => {
    const unlocked = StorageService.unlockAchievement(id);
    if (unlocked) {
      setAchievements(StorageService.getAchievements());
      setAchievementToast(unlocked);
      sound.playStamp(true);
      setTimeout(() => {
        setAchievementToast(null);
      }, 3500);
    }
  };

  // Sound toggle
  const handleToggleSound = () => {
    const muted = sound.toggleMute();
    setIsMuted(muted);
    if (!muted) {
      sound.playClick();
    }
  };

  // Start fresh game
  const handleStartGame = () => {
    setCurrentLevel(1);
    setAttempts(3);
    setStats({
      timeElapsed: 0,
      boilerBreaches: 0,
      attemptsLost: 0,
      steamVentedLiters: 20,
      permitsSubmitted: 0,
      insultsEndured: 4,
    });
    setCurrentScreen('PLAYING');
  };

  // Restart current level
  const handleRestartLevel = () => {
    setAttempts(3);
    setIsPaused(false);
    setCurrentScreen('PLAYING');
  };

  // Level Success handler
  const handleLevelSuccess = () => {
    if (currentLevel === 1) {
      awardAchievement('button_presser');
    } else if (currentLevel === 3) {
      awardAchievement('gear_survivor');
    } else if (currentLevel === 4) {
      awardAchievement('government_approved');
    }

    if (currentLevel < 5) {
      setCurrentScreen('TRANSITION');
    } else {
      // Completed Level 5 -> VICTORY!
      awardAchievement('worst_inventor');
      StorageService.saveBestTime(stats.timeElapsed);
      setBestTime(StorageService.getBestTime());
      setCurrentScreen('VICTORY');
    }
  };

  // Proceed from Transition
  const handleProceedNextLevel = () => {
    const next = (currentLevel + 1) as LevelId;
    setCurrentLevel(next);
    setAttempts(3);
    setCurrentScreen('PLAYING');
  };

  // Fail attempt (e.g. wrong lever or pressure slip)
  const handleFailAttempt = () => {
    triggerShake('mild');
    setStats(prev => ({
      ...prev,
      attemptsLost: prev.attemptsLost + 1,
      insultsEndured: prev.insultsEndured + 1,
    }));

    setAttempts(prev => {
      const next = prev - 1;
      if (next <= 0) {
        // Catastrophic attempt loss
        setGameOverReason("All auxiliary safety fuses melted into a single copper puddle.");
        setCurrentScreen('GAMEOVER');
        return 0;
      }
      return next;
    });
  };

  // Boiler explosion handler
  const handleBoilerExplode = () => {
    triggerShake('violent');
    awardAchievement('steam_victim');
    setStats(prev => ({
      ...prev,
      boilerBreaches: prev.boilerBreaches + 1,
      insultsEndured: prev.insultsEndured + 2,
    }));
    setGameOverReason("Boiler pressure breached 100 PSI. The iron kettle reached low earth orbit.");
    setCurrentScreen('GAMEOVER');
  };

  const currentConfig = LEVEL_CONFIGS[currentLevel];
  const nextConfig = currentLevel < 5 ? LEVEL_CONFIGS[(currentLevel + 1) as LevelId] : null;

  return (
    <div
      className={`min-h-screen bg-[#1c120c] text-[#f5e6c8] flex flex-col justify-between selection:bg-[#d4af37] selection:text-black ${
        screenShake === 'mild'
          ? 'animate-shake-mild'
          : screenShake === 'violent'
          ? 'animate-shake-violent'
          : ''
      }`}
    >
      {/* Achievement Unlock Toast Notification */}
      {achievementToast && (
        <div className="fixed top-4 right-4 z-50 bg-[#29170e] border-2 border-[#ffd700] rounded-lg p-3 shadow-2xl flex items-center gap-3 animate-in slide-in-from-top duration-300">
          <span className="text-2xl">{achievementToast.icon}</span>
          <div>
            <span className="text-[10px] font-mono-steampunk text-[#d4af37] tracking-wider uppercase block font-bold">
              🏆 IMPERIAL MEDAL CONFERRED
            </span>
            <h4 className="font-victorian text-xs font-bold text-white">
              {achievementToast.title}
            </h4>
          </div>
        </div>
      )}

      {/* Header HUD (Visible during gameplay and transitions) */}
      {currentScreen === 'PLAYING' && (
        <HeaderHUD
          level={currentLevel}
          levelTitle={currentConfig.title}
          levelSubtitle={currentConfig.subtitle}
          attempts={attempts}
          timeElapsed={stats.timeElapsed}
          isPaused={isPaused}
          isMuted={isMuted}
          onTogglePause={() => setIsPaused(prev => !prev)}
          onToggleSound={handleToggleSound}
          onRestartLevel={handleRestartLevel}
          onOpenAchievements={() => setShowAchievements(true)}
          onOpenLeaderboard={() => setShowLeaderboard(true)}
          unlockedCount={achievements.filter(a => a.unlocked).length}
          totalAchievements={achievements.length}
        />
      )}

      {/* Main Content Viewport */}
      <main className="flex-1 flex flex-col justify-center items-center p-3 sm:p-6 w-full max-w-6xl mx-auto">
        {currentScreen === 'TITLE' && (
          <TitleScreen
            onStart={handleStartGame}
            onInstructions={() => setCurrentScreen('INSTRUCTIONS')}
            onAchievements={() => setShowAchievements(true)}
            onLeaderboard={() => setShowLeaderboard(true)}
            isMuted={isMuted}
            onToggleSound={handleToggleSound}
            bestTime={bestTime}
          />
        )}

        {currentScreen === 'INSTRUCTIONS' && (
          <InstructionsScreen
            onBack={() => setCurrentScreen('TITLE')}
            onStart={handleStartGame}
          />
        )}

        {currentScreen === 'PLAYING' && (
          <div className="w-full">
            {currentLevel === 1 && (
              <Level1WakeMachine
                onSuccess={handleLevelSuccess}
                onFailAttempt={handleFailAttempt}
                attempts={attempts}
              />
            )}
            {currentLevel === 2 && (
              <Level2BoilerPanic
                onSuccess={handleLevelSuccess}
                onExplode={handleBoilerExplode}
                attempts={attempts}
              />
            )}
            {currentLevel === 3 && (
              <Level3GearDisaster
                onSuccess={handleLevelSuccess}
                attempts={attempts}
              />
            )}
            {currentLevel === 4 && (
              <Level4DepartmentOfPermissions
                onSuccess={handleLevelSuccess}
                attempts={attempts}
              />
            )}
            {currentLevel === 5 && (
              <Level5FinalCupOfTea
                onSuccess={handleLevelSuccess}
                onExplode={handleBoilerExplode}
              />
            )}
          </div>
        )}

        {currentScreen === 'TRANSITION' && nextConfig && (
          <LevelTransitionScreen
            completedLevel={currentLevel}
            nextLevel={nextConfig.id}
            nextLevelTitle={nextConfig.title}
            nextLevelSubtitle={nextConfig.subtitle}
            onProceed={handleProceedNextLevel}
          />
        )}

        {currentScreen === 'GAMEOVER' && (
          <GameOverScreen
            level={currentLevel}
            reason={gameOverReason}
            onRetryLevel={handleRestartLevel}
            onRestartGame={handleStartGame}
          />
        )}

        {currentScreen === 'VICTORY' && (
          <VictoryScreen
            stats={stats}
            achievements={achievements}
            onRestart={handleStartGame}
            onOpenLeaderboard={() => setShowLeaderboard(true)}
          />
        )}
      </main>

      {/* Pause Menu Overlay */}
      {isPaused && (
        <PauseMenu
          onResume={() => setIsPaused(false)}
          onRestartLevel={handleRestartLevel}
          onShowManual={() => {
            setIsPaused(false);
            setCurrentScreen('INSTRUCTIONS');
          }}
          onQuitToTitle={() => {
            setIsPaused(false);
            setCurrentScreen('TITLE');
          }}
          isMuted={isMuted}
          onToggleSound={handleToggleSound}
        />
      )}

      {/* Achievements Modal */}
      <AchievementsModal
        isOpen={showAchievements}
        onClose={() => setShowAchievements(false)}
        achievements={achievements}
      />

      {/* Global Leaderboard Modal (Firestore) */}
      <LeaderboardModal
        isOpen={showLeaderboard}
        onClose={() => setShowLeaderboard(false)}
      />

      {/* Subdued Footer */}
      <footer className="w-full py-2 px-4 border-t border-[#4a2e18] bg-[#140c07] text-center text-[10px] font-mono-steampunk text-[#874b17]">
        <span>STEAM.exe • Victorian Inconvenience Simulator • Designed for the Hackathon</span>
      </footer>
    </div>
  );
}
